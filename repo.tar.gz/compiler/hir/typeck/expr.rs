use super::{
    Arg, BinaryOp, Body, ClassIndex, EnumIndex, Expr, FunctionIndex, FunctionRole, Idx,
    InterfaceIndex, Literal, SmolStr, Type, TypeContext, TypeError, TypeRef, UnaryOp,
    actor_type_for_detach_target, binary_from_assign, binary_op_label, binary_result, body_key,
    build_type_subst, callee_error_span, check_class_init_args, check_type_param_bounds,
    class_subst, collection_method_sig, error_type, infer_list, infer_map,
    instantiate_method_params, instantiate_method_ret, is_assignable, is_pool_of_call,
    is_pool_of_member, is_portable_named_data_type_name, literal_type, portable_named_field_type,
    portable_named_type, requires_named_args, resolve_type_args, same_vector_kind, span_from_range,
    substitute_type, type_from_ref, type_from_ref_in_ctx, type_label, types_known, unary_op_label,
    unary_result, valid_binary, valid_equality_operands, valid_unary,
};
use std::collections::{HashMap, HashSet};

pub(super) fn infer_expr(
    body: &Body,
    expr_id: Idx<Expr>,
    ctx: &mut TypeContext,
    classes: &ClassIndex,
    enums: &EnumIndex,
    interfaces: &InterfaceIndex,
    functions: &FunctionIndex,
    errors: &mut Vec<TypeError>,
    allow_pending: bool,
    allow_result: bool,
    in_result_fn: bool,
) -> Type {
    let ty = match &body.exprs[expr_id] {
        Expr::Literal(lit) => literal_type(lit),
        Expr::Variable(name) => match name.as_str() {
            "coarse" | "fine" => detail_tier_type(),
            _ => ctx
                .resolve(name)
                .or_else(|| {
                    crate::query_contract::query_family_namespace(name.as_str())
                        .map(Type::QueryFamily)
                })
                .unwrap_or(Type::Unknown),
        },
        Expr::Detach { target, .. } => actor_type_for_detach_target(body, *target, classes),
        Expr::Unary { op, expr, op_span } => {
            let allow_pending_operand = matches!(op, UnaryOp::Await | UnaryOp::Fire);
            let allow_result_operand = allow_result || matches!(op, UnaryOp::Try);
            let operand = infer_expr(
                body,
                *expr,
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                allow_pending_operand,
                allow_result_operand,
                in_result_fn,
            );
            if matches!(op, UnaryOp::Err) && !in_result_fn {
                errors.push(TypeError::ErrOutsideResult {
                    span: span_from_range(*op_span),
                });
                Type::Unknown
            } else if matches!(op, UnaryOp::Try) && !in_result_fn {
                errors.push(TypeError::TryOutsideResult {
                    span: span_from_range(*op_span),
                });
                Type::Unknown
            } else if matches!(op, UnaryOp::Try) {
                match operand {
                    Type::Result(ok, _err) => *ok,
                    Type::Unknown => Type::Unknown,
                    _ => {
                        errors.push(TypeError::InvalidTryOperand {
                            span: span_from_range(*op_span),
                        });
                        Type::Unknown
                    }
                }
            } else if operand != Type::Unknown && !valid_unary(*op, &operand) {
                errors.push(TypeError::InvalidUnaryOperand {
                    op: unary_op_label(*op),
                    span: span_from_range(*op_span),
                });
                Type::Unknown
            } else if matches!(op, UnaryOp::Spawn) {
                actor_type_for_detach_target(body, *expr, classes)
            } else if matches!(op, UnaryOp::Await) {
                match operand {
                    Type::Pending(inner) => match *inner {
                        Type::Result(ok, err) => Type::Result(ok, err),
                        other => Type::Result(Box::new(other), Box::new(error_type())),
                    },
                    Type::Unknown => Type::Unknown,
                    _ => {
                        errors.push(TypeError::InvalidAwaitOperand {
                            span: span_from_range(*op_span),
                        });
                        Type::Unknown
                    }
                }
            } else if matches!(op, UnaryOp::Fire) {
                match operand {
                    Type::Pending(_) => Type::Nil,
                    Type::Unknown => Type::Unknown,
                    _ => {
                        errors.push(TypeError::InvalidFireOperand {
                            span: span_from_range(*op_span),
                        });
                        Type::Unknown
                    }
                }
            } else {
                unary_result(*op, &operand)
            }
        }
        Expr::Binary {
            lhs,
            op,
            rhs,
            op_span,
        } => {
            if matches!(
                op,
                BinaryOp::Assign
                    | BinaryOp::AddAssign
                    | BinaryOp::SubAssign
                    | BinaryOp::MulAssign
                    | BinaryOp::DivAssign
            ) && let Expr::Index {
                object,
                index,
                index_span,
            } = &body.exprs[*lhs]
            {
                let object_ty = infer_expr(
                    body,
                    *object,
                    ctx,
                    classes,
                    enums,
                    interfaces,
                    functions,
                    errors,
                    false,
                    allow_result,
                    in_result_fn,
                );
                let index_ty = infer_expr(
                    body,
                    *index,
                    ctx,
                    classes,
                    enums,
                    interfaces,
                    functions,
                    errors,
                    false,
                    allow_result,
                    in_result_fn,
                );
                let right_ty = infer_expr(
                    body,
                    *rhs,
                    ctx,
                    classes,
                    enums,
                    interfaces,
                    functions,
                    errors,
                    false,
                    allow_result,
                    in_result_fn,
                );
                match object_ty {
                    Type::List(inner_ty) | Type::Array(inner_ty, _) => {
                        if types_known(&Type::Integer, &index_ty) && index_ty != Type::Integer {
                            errors.push(TypeError::InvalidIndexType {
                                expected: "Integer".to_string(),
                                found: type_label(&index_ty),
                                span: span_from_range(*index_span),
                            });
                        }
                        if matches!(op, BinaryOp::Assign) {
                            if types_known(&inner_ty, &right_ty)
                                && !is_assignable(&inner_ty, &right_ty, classes, interfaces)
                            {
                                errors.push(TypeError::InvalidAssignment {
                                    name: SmolStr::new("index"),
                                    expected: type_label(&inner_ty),
                                    found: type_label(&right_ty),
                                    span: span_from_range(*op_span),
                                });
                            }
                        } else if types_known(&inner_ty, &right_ty)
                            && !valid_binary(binary_from_assign(*op), &inner_ty, &right_ty)
                        {
                            errors.push(TypeError::InvalidBinaryOperands {
                                op: binary_op_label(binary_from_assign(*op)),
                                span: span_from_range(*op_span),
                            });
                        }
                    }
                    Type::Map(key_ty, value_ty) => {
                        if types_known(&key_ty, &index_ty)
                            && !is_assignable(&key_ty, &index_ty, classes, interfaces)
                        {
                            errors.push(TypeError::InvalidIndexType {
                                expected: type_label(&key_ty),
                                found: type_label(&index_ty),
                                span: span_from_range(*index_span),
                            });
                        }
                        if matches!(op, BinaryOp::Assign) {
                            if types_known(&value_ty, &right_ty)
                                && !is_assignable(&value_ty, &right_ty, classes, interfaces)
                            {
                                errors.push(TypeError::InvalidAssignment {
                                    name: SmolStr::new("index"),
                                    expected: type_label(&value_ty),
                                    found: type_label(&right_ty),
                                    span: span_from_range(*op_span),
                                });
                            }
                        } else if types_known(&value_ty, &right_ty)
                            && !valid_binary(binary_from_assign(*op), &value_ty, &right_ty)
                        {
                            errors.push(TypeError::InvalidBinaryOperands {
                                op: binary_op_label(binary_from_assign(*op)),
                                span: span_from_range(*op_span),
                            });
                        }
                    }
                    Type::Unknown => {}
                    _ => errors.push(TypeError::InvalidIndexTarget {
                        span: span_from_range(*index_span),
                    }),
                }
                return Type::Unknown;
            }
            if matches!(
                op,
                BinaryOp::Assign
                    | BinaryOp::AddAssign
                    | BinaryOp::SubAssign
                    | BinaryOp::MulAssign
                    | BinaryOp::DivAssign
            ) && let Expr::Member { object, member, .. } = &body.exprs[*lhs]
            {
                let object_ty = infer_expr(
                    body,
                    *object,
                    ctx,
                    classes,
                    enums,
                    interfaces,
                    functions,
                    errors,
                    false,
                    allow_result,
                    in_result_fn,
                );
                let right_ty = infer_expr(
                    body,
                    *rhs,
                    ctx,
                    classes,
                    enums,
                    interfaces,
                    functions,
                    errors,
                    false,
                    allow_result,
                    in_result_fn,
                );
                if let Type::Actor(_) = object_ty {
                    errors.push(TypeError::ActorMemberAccess {
                        member: member.clone(),
                        span: span_from_range(*op_span),
                    });
                    return Type::Unknown;
                }
                if let Some(_) = vector_component_type(&object_ty, member) {
                    errors.push(TypeError::ImmutableFieldAssign {
                        member: member.clone(),
                        span: span_from_range(*op_span),
                        help: "Vector components are read-only projections; construct a new vector instead.".to_string(),
                    });
                    return Type::Unknown;
                }
                if matches!(
                    &object_ty,
                    Type::Vec2 | Type::Vec3 | Type::Vec4 | Type::Quat | Type::Mat3 | Type::Mat4
                ) {
                    errors.push(TypeError::UnknownMember {
                        object: type_label(&object_ty),
                        member: member.clone(),
                        span: span_from_range(*op_span),
                    });
                    return Type::Unknown;
                }
                if let Type::Named(class_name, class_args) = object_ty {
                    if interfaces.is_interface(&class_name) {
                        errors.push(TypeError::UnknownMember {
                            object: class_name.to_string(),
                            member: member.clone(),
                            span: span_from_range(*op_span),
                        });
                    } else if let Some(class) = classes.get(&class_name) {
                        let subst = class_subst(class, &class_args);
                        if let Some(field_ty) = class.fields.get(member) {
                            let field_mutable =
                                class.field_mutable.get(member).copied().unwrap_or(false);
                            if !field_mutable {
                                errors.push(TypeError::ImmutableFieldAssign {
                                    member: member.clone(),
                                    span: span_from_range(*op_span),
                                    help: "Mark the field as mutable in the `has` block."
                                        .to_string(),
                                });
                            }
                            let field_ty = substitute_type(field_ty, &subst);
                            if matches!(op, BinaryOp::Assign) {
                                if types_known(&field_ty, &right_ty)
                                    && !is_assignable(&field_ty, &right_ty, classes, interfaces)
                                {
                                    errors.push(TypeError::InvalidAssignment {
                                        name: member.clone(),
                                        expected: type_label(&field_ty),
                                        found: type_label(&right_ty),
                                        span: span_from_range(*op_span),
                                    });
                                }
                            } else if types_known(&field_ty, &right_ty)
                                && !valid_binary(binary_from_assign(*op), &field_ty, &right_ty)
                            {
                                errors.push(TypeError::InvalidBinaryOperands {
                                    op: binary_op_label(binary_from_assign(*op)),
                                    span: span_from_range(*op_span),
                                });
                            }
                        } else if class.methods.contains_key(member) {
                            errors.push(TypeError::InvalidAssignment {
                                name: member.clone(),
                                expected: "field".to_string(),
                                found: "method".to_string(),
                                span: span_from_range(*op_span),
                            });
                        } else {
                            errors.push(TypeError::UnknownMember {
                                object: class_name.to_string(),
                                member: member.clone(),
                                span: span_from_range(*op_span),
                            });
                        }
                    }
                }
                return Type::Unknown;
            }
            if matches!(op, BinaryOp::Otherwise) {
                let left = infer_expr(
                    body,
                    *lhs,
                    ctx,
                    classes,
                    enums,
                    interfaces,
                    functions,
                    errors,
                    false,
                    true,
                    in_result_fn,
                );
                let right = infer_expr(
                    body,
                    *rhs,
                    ctx,
                    classes,
                    enums,
                    interfaces,
                    functions,
                    errors,
                    false,
                    allow_result,
                    in_result_fn,
                );
                match left {
                    Type::Result(ok, _err) => {
                        if types_known(&ok, &right)
                            && !is_assignable(&ok, &right, classes, interfaces)
                        {
                            errors.push(TypeError::InvalidBinaryOperands {
                                op: binary_op_label(*op),
                                span: span_from_range(*op_span),
                            });
                        }
                        if matches!(*ok, Type::Unknown) {
                            right
                        } else {
                            *ok
                        }
                    }
                    Type::Unknown => Type::Unknown,
                    _ => {
                        errors.push(TypeError::InvalidOtherwiseOperand {
                            span: span_from_range(*op_span),
                        });
                        Type::Unknown
                    }
                }
            } else {
                let left = infer_expr(
                    body,
                    *lhs,
                    ctx,
                    classes,
                    enums,
                    interfaces,
                    functions,
                    errors,
                    false,
                    allow_result,
                    in_result_fn,
                );
                let right = infer_expr(
                    body,
                    *rhs,
                    ctx,
                    classes,
                    enums,
                    interfaces,
                    functions,
                    errors,
                    false,
                    allow_result,
                    in_result_fn,
                );
                if matches!(op, BinaryOp::Eq | BinaryOp::Ne)
                    && types_known(&left, &right)
                    && !valid_equality_operands(&left, &right, classes, enums, interfaces)
                {
                    errors.push(TypeError::EqualityRequiresEq {
                        left: type_label(&left),
                        right: type_label(&right),
                        span: span_from_range(*op_span),
                    });
                    return Type::Unknown;
                }
                if types_known(&left, &right) && !valid_binary(*op, &left, &right) {
                    errors.push(TypeError::InvalidBinaryOperands {
                        op: binary_op_label(*op),
                        span: span_from_range(*op_span),
                    });
                    Type::Unknown
                } else {
                    binary_result(*op, &left, &right)
                }
            }
        }
        Expr::TypeApply { callee, type_args } => {
            let _ = infer_expr(
                body,
                *callee,
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                false,
                allow_result,
                in_result_fn,
            );
            if !type_args.is_empty() {
                errors.push(TypeError::TypeApplyWithoutCall {
                    span: span_from_range(body.expr_span(expr_id)),
                });
            }
            Type::Unknown
        }
        Expr::Crash { expr } => {
            let _ = infer_expr(
                body,
                *expr,
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                false,
                allow_result,
                in_result_fn,
            );
            Type::Never
        }
        Expr::Call { .. } => {
            let (callee, args, type_args) = match &body.exprs[expr_id] {
                Expr::Call {
                    callee,
                    args,
                    type_args,
                } => (callee, args, type_args),
                _ => unreachable!(),
            };
            for arg in args {
                match arg {
                    crate::hir::Arg::Positional { value, .. } => {
                        infer_expr(
                            body,
                            *value,
                            ctx,
                            classes,
                            enums,
                            interfaces,
                            functions,
                            errors,
                            false,
                            allow_result,
                            in_result_fn,
                        );
                    }
                    crate::hir::Arg::Named { value, .. } => {
                        infer_expr(
                            body,
                            *value,
                            ctx,
                            classes,
                            enums,
                            interfaces,
                            functions,
                            errors,
                            false,
                            allow_result,
                            in_result_fn,
                        );
                    }
                }
            }
            let mut ret_ty = None;
            let mut valid_callee = false;
            if is_pool_of_call(body, *callee) {
                ret_ty = Some(Type::Unknown);
                valid_callee = true;
            }
            if let Expr::Variable(name) = &body.exprs[*callee] {
                if let Some(ret) = infer_math_builtin_call(
                    body,
                    expr_id,
                    name,
                    args,
                    ctx,
                    classes,
                    enums,
                    interfaces,
                    functions,
                    errors,
                    allow_result,
                    in_result_fn,
                ) {
                    ret_ty = Some(ret);
                    valid_callee = true;
                }
                if !valid_callee
                    && let Some(ret) = infer_compute_builtin_call(
                        body,
                        expr_id,
                        name,
                        args,
                        ctx,
                        classes,
                        enums,
                        interfaces,
                        functions,
                        errors,
                        allow_result,
                        in_result_fn,
                    )
                {
                    ret_ty = Some(ret);
                    valid_callee = true;
                }
                if classes.is_class(name) {
                    if let Some(record) = crate::portable::builtin_record(name.as_str())
                        && !record.constructible
                    {
                        errors.push(TypeError::OpaqueBuiltinConstructionForbidden {
                            name: name.clone(),
                            span: span_from_range(body.expr_span(expr_id)),
                            help: format!(
                                "Use the builtin entrypoint that produces `{}` instead of constructing it directly.",
                                name
                            ),
                        });
                        ret_ty = Some(Type::Named(name.clone(), Vec::new()));
                        valid_callee = true;
                    } else if let Some(class) = classes.get(name) {
                        let class_args = resolve_type_args(
                            name,
                            &class.type_params,
                            type_args,
                            ctx,
                            errors,
                            span_from_range(body.expr_span(expr_id)),
                        );
                        check_class_init_args(
                            body,
                            expr_id,
                            args,
                            class,
                            &class_args,
                            ctx,
                            classes,
                            enums,
                            interfaces,
                            functions,
                            errors,
                            allow_result,
                            in_result_fn,
                        );
                        ret_ty = Some(Type::Named(name.clone(), class_args));
                        valid_callee = true;
                    } else {
                        ret_ty = Some(Type::Named(name.clone(), Vec::new()));
                        valid_callee = true;
                    }
                }
                if !valid_callee
                    && let Some(record) = crate::portable::builtin_record_by_function(name.as_str())
                {
                    let class_name = SmolStr::new(record.name);
                    if let Some(class) = classes.get(&class_name) {
                        check_class_init_args(
                            body,
                            expr_id,
                            args,
                            class,
                            &[],
                            ctx,
                            classes,
                            enums,
                            interfaces,
                            functions,
                            errors,
                            allow_result,
                            in_result_fn,
                        );
                        ret_ty = Some(Type::Named(class_name, Vec::new()));
                        valid_callee = true;
                    }
                }
                if !valid_callee && let Some(function) = functions.get(name) {
                    if ctx.in_portable_lane()
                        && !functions.is_portable(name)
                        && !(ctx.in_portable_query_kernel_lane() && functions.is_domain(name))
                    {
                        errors.push(TypeError::PortableHostCallForbidden {
                            function: ctx.current_function_name(),
                            callee: name.clone(),
                            span: span_from_range(body.expr_span(expr_id)),
                            help: "Portable declarations may only call other portable declarations or portable-safe intrinsics.".to_string(),
                        });
                    }
                    if ctx.in_portable_lane()
                        && matches!(ctx.current_function_role(), FunctionRole::Pure)
                        && functions.is_kernel(name)
                    {
                        errors.push(TypeError::PortableConstructForbidden {
                            function: ctx.current_function_name(),
                            construct: format!("calling kernel declaration '{}'", name),
                            span: span_from_range(body.expr_span(expr_id)),
                            help: "Pure helpers stay reusable across host code, semantic portable code, and kernels. Call other `pure fn` helpers instead of jumping into low-level `kernel fn` entry points.".to_string(),
                        });
                    }
                    if !type_args.is_empty() {
                        if function.type_params.is_empty() {
                            errors.push(TypeError::UnexpectedTypeArgs {
                                span: span_from_range(body.expr_span(expr_id)),
                            });
                        } else {
                            // Generic function call with explicit type args — check bounds
                            let resolved_type_args: Vec<Type> =
                                type_args.iter().map(type_from_ref).collect();
                            check_type_param_bounds(
                                &function.type_params,
                                &function.type_param_bounds,
                                &resolved_type_args,
                                classes,
                                span_from_range(body.expr_span(expr_id)),
                                errors,
                            );
                        }
                    }
                    if name.as_str() == "assert" && args.len() == 1 && function.params.len() == 2 {
                        let mut params = Vec::new();
                        params.push(function.params[0].clone());
                        check_call_args(
                            body,
                            expr_id,
                            args,
                            &params,
                            ctx,
                            classes,
                            enums,
                            interfaces,
                            functions,
                            errors,
                            !name.as_str().starts_with("__wr_"),
                            allow_result,
                            in_result_fn,
                        );
                    } else {
                        check_call_args(
                            body,
                            expr_id,
                            args,
                            &function.params,
                            ctx,
                            classes,
                            enums,
                            interfaces,
                            functions,
                            errors,
                            !builtin_allows_positional_args(name),
                            allow_result,
                            in_result_fn,
                        );
                    }
                    ret_ty = Some(function.ret.clone());
                    valid_callee = true;
                }
                if !valid_callee && ctx.resolve(name).is_some() {
                    errors.push(TypeError::InvalidCallee {
                        span: callee_error_span(body, *callee),
                    });
                }
            }
            let mut handled_member = false;
            if ret_ty.is_none()
                && let Expr::Member {
                    object,
                    member,
                    member_span,
                } = &body.exprs[*callee]
            {
                handled_member = true;
                if !type_args.is_empty() {
                    errors.push(TypeError::UnexpectedTypeArgs {
                        span: span_from_range(body.expr_span(expr_id)),
                    });
                }
                let mut enum_ctor_handled = false;
                let mut enum_name_opt: Option<SmolStr> = None;
                let mut enum_type_args: Vec<TypeRef> = Vec::new();
                if let Expr::Variable(enum_name) = &body.exprs[*object] {
                    enum_name_opt = Some(enum_name.clone());
                } else if let Expr::TypeApply { callee, type_args } = &body.exprs[*object]
                    && let Expr::Variable(enum_name) = &body.exprs[*callee]
                {
                    enum_name_opt = Some(enum_name.clone());
                    enum_type_args = type_args.clone();
                }
                if let Some(enum_name) = enum_name_opt
                    && let Some(en) = enums.get(&enum_name)
                    && let Some(params) = en.variants.get(member)
                {
                    let resolved_args = resolve_type_args(
                        &enum_name,
                        &en.type_params,
                        &enum_type_args,
                        ctx,
                        errors,
                        span_from_range(body.expr_span(*object)),
                    );
                    let subst = build_type_subst(&en.type_params, &resolved_args);
                    let params: Vec<(SmolStr, Type)> = params
                        .iter()
                        .map(|(name, ty)| (name.clone(), substitute_type(ty, &subst)))
                        .collect();
                    check_call_args(
                        body,
                        expr_id,
                        args,
                        &params,
                        ctx,
                        classes,
                        enums,
                        interfaces,
                        functions,
                        errors,
                        true,
                        allow_result,
                        in_result_fn,
                    );
                    ret_ty = Some(Type::Named(enum_name.clone(), resolved_args));
                    valid_callee = true;
                    enum_ctor_handled = true;
                }
                if is_pool_of_member(body, *object, member) {
                    ret_ty = Some(Type::Unknown);
                    valid_callee = true;
                }
                if !valid_callee && let Some(family) = query_family_object(body, *object, ctx) {
                    if let Some(ret) = infer_family_query_member_builtin(
                        body,
                        expr_id,
                        family,
                        member,
                        args,
                        ctx,
                        classes,
                        enums,
                        interfaces,
                        functions,
                        errors,
                        allow_result,
                        in_result_fn,
                    ) {
                        ret_ty = Some(ret);
                    } else {
                        errors.push(TypeError::UnknownMember {
                            object: format!(
                                "{} query family",
                                crate::query_contract::query_family_name(family)
                            ),
                            member: member.clone(),
                            span: span_from_range(*member_span),
                        });
                        ret_ty = Some(Type::Unknown);
                    }
                    valid_callee = true;
                }
                if !enum_ctor_handled && !valid_callee {
                    let object_ty = infer_expr(
                        body,
                        *object,
                        ctx,
                        classes,
                        enums,
                        interfaces,
                        functions,
                        errors,
                        false,
                        allow_result,
                        in_result_fn,
                    );
                    if let Some((params, ret)) = collection_method_sig(&object_ty, member) {
                        check_call_args(
                            body,
                            expr_id,
                            args,
                            &params,
                            ctx,
                            classes,
                            enums,
                            interfaces,
                            functions,
                            errors,
                            true,
                            allow_result,
                            in_result_fn,
                        );
                        ret_ty = Some(ret);
                        valid_callee = true;
                    } else {
                        match object_ty {
                            Type::Actor(inner) => {
                                if let Type::Named(class_name, class_args) = *inner
                                    && let Some(class) = classes.get(&class_name)
                                {
                                    let method_params =
                                        instantiate_method_params(class, &class_args, member);
                                    let method_ret =
                                        instantiate_method_ret(class, &class_args, member);
                                    if let Some(method) = class.methods.get(member) {
                                        let params = method_params.unwrap_or(method.params.clone());
                                        check_call_args(
                                            body,
                                            expr_id,
                                            args,
                                            &params,
                                            ctx,
                                            classes,
                                            enums,
                                            interfaces,
                                            functions,
                                            errors,
                                            true,
                                            allow_result,
                                            in_result_fn,
                                        );
                                        let ret = method_ret.unwrap_or(method.ret.clone());
                                        ret_ty = Some(Type::Pending(Box::new(Type::Result(
                                            Box::new(ret),
                                            Box::new(error_type()),
                                        ))));
                                        valid_callee = true;
                                    } else {
                                        errors.push(TypeError::UnknownMember {
                                            object: class_name.to_string(),
                                            member: member.clone(),
                                            span: span_from_range(*member_span),
                                        });
                                        ret_ty = Some(Type::Unknown);
                                    }
                                }
                            }
                            Type::Vec2 => {
                                if matches!(member.as_str(), "x" | "y") {
                                    errors.push(TypeError::CallField {
                                        member: member.clone(),
                                        span: span_from_range(*member_span),
                                    });
                                } else {
                                    errors.push(TypeError::UnknownMember {
                                        object: "Vec2".to_string(),
                                        member: member.clone(),
                                        span: span_from_range(*member_span),
                                    });
                                }
                                ret_ty = Some(Type::Unknown);
                                valid_callee = true;
                            }
                            Type::Vec3 => {
                                if matches!(member.as_str(), "x" | "y" | "z") {
                                    errors.push(TypeError::CallField {
                                        member: member.clone(),
                                        span: span_from_range(*member_span),
                                    });
                                } else {
                                    errors.push(TypeError::UnknownMember {
                                        object: "Vec3".to_string(),
                                        member: member.clone(),
                                        span: span_from_range(*member_span),
                                    });
                                }
                                ret_ty = Some(Type::Unknown);
                                valid_callee = true;
                            }
                            Type::Vec4 => {
                                if matches!(member.as_str(), "x" | "y" | "z" | "w") {
                                    errors.push(TypeError::CallField {
                                        member: member.clone(),
                                        span: span_from_range(*member_span),
                                    });
                                } else {
                                    errors.push(TypeError::UnknownMember {
                                        object: "Vec4".to_string(),
                                        member: member.clone(),
                                        span: span_from_range(*member_span),
                                    });
                                }
                                ret_ty = Some(Type::Unknown);
                                valid_callee = true;
                            }
                            Type::Quat => {
                                if matches!(member.as_str(), "x" | "y" | "z" | "w") {
                                    errors.push(TypeError::CallField {
                                        member: member.clone(),
                                        span: span_from_range(*member_span),
                                    });
                                } else {
                                    errors.push(TypeError::UnknownMember {
                                        object: "Quat".to_string(),
                                        member: member.clone(),
                                        span: span_from_range(*member_span),
                                    });
                                }
                                ret_ty = Some(Type::Unknown);
                                valid_callee = true;
                            }
                            Type::Mat3 => {
                                errors.push(TypeError::UnknownMember {
                                    object: "Mat3".to_string(),
                                    member: member.clone(),
                                    span: span_from_range(*member_span),
                                });
                                ret_ty = Some(Type::Unknown);
                                valid_callee = true;
                            }
                            Type::Mat4 => {
                                errors.push(TypeError::UnknownMember {
                                    object: "Mat4".to_string(),
                                    member: member.clone(),
                                    span: span_from_range(*member_span),
                                });
                                ret_ty = Some(Type::Unknown);
                                valid_callee = true;
                            }
                            Type::Named(class_name, class_args)
                                if class_args.is_empty()
                                    && is_portable_named_data_type_name(class_name.as_str()) =>
                            {
                                if portable_named_field_type(class_name.as_str(), member.as_str())
                                    .is_some()
                                {
                                    errors.push(TypeError::CallField {
                                        member: member.clone(),
                                        span: span_from_range(*member_span),
                                    });
                                } else {
                                    errors.push(TypeError::UnknownMember {
                                        object: class_name.to_string(),
                                        member: member.clone(),
                                        span: span_from_range(*member_span),
                                    });
                                }
                                ret_ty = Some(Type::Unknown);
                                valid_callee = true;
                            }
                            Type::Named(class_name, class_args)
                                if interfaces.is_interface(&class_name) =>
                            {
                                if let Some(interface) = interfaces.get(&class_name) {
                                    if let Some(method) = interface.methods.get(member) {
                                        let params = method.params.clone();
                                        check_call_args(
                                            body,
                                            expr_id,
                                            args,
                                            &params,
                                            ctx,
                                            classes,
                                            enums,
                                            interfaces,
                                            functions,
                                            errors,
                                            true,
                                            allow_result,
                                            in_result_fn,
                                        );
                                        ret_ty = Some(method.ret.clone());
                                        valid_callee = true;
                                    } else {
                                        errors.push(TypeError::UnknownMember {
                                            object: class_name.to_string(),
                                            member: member.clone(),
                                            span: span_from_range(*member_span),
                                        });
                                        ret_ty = Some(Type::Unknown);
                                    }
                                }
                            }
                            Type::Named(class_name, class_args) => {
                                if let Some(class) = classes.get(&class_name) {
                                    let method_params =
                                        instantiate_method_params(class, &class_args, member);
                                    let method_ret =
                                        instantiate_method_ret(class, &class_args, member);
                                    if let Some(method) = class.methods.get(member) {
                                        let params = method_params.unwrap_or(method.params.clone());
                                        check_call_args(
                                            body,
                                            expr_id,
                                            args,
                                            &params,
                                            ctx,
                                            classes,
                                            enums,
                                            interfaces,
                                            functions,
                                            errors,
                                            true,
                                            allow_result,
                                            in_result_fn,
                                        );
                                        ret_ty = Some(method_ret.unwrap_or(method.ret.clone()));
                                        valid_callee = true;
                                    } else if class.fields.contains_key(member) {
                                        errors.push(TypeError::CallField {
                                            member: member.clone(),
                                            span: span_from_range(*member_span),
                                        });
                                        ret_ty = Some(Type::Unknown);
                                    } else {
                                        errors.push(TypeError::UnknownMember {
                                            object: class_name.to_string(),
                                            member: member.clone(),
                                            span: span_from_range(*member_span),
                                        });
                                        ret_ty = Some(Type::Unknown);
                                    }
                                }
                            }
                            Type::Unknown => {}
                            _ => {
                                errors.push(TypeError::InvalidCallee {
                                    span: span_from_range(*member_span),
                                });
                            }
                        }
                    }
                }
            }
            if ret_ty.is_none() && !handled_member {
                if !matches!(&body.exprs[*callee], Expr::Variable(_)) {
                    errors.push(TypeError::InvalidCallee {
                        span: callee_error_span(body, *callee),
                    });
                }
                let _ = infer_expr(
                    body,
                    *callee,
                    ctx,
                    classes,
                    enums,
                    interfaces,
                    functions,
                    errors,
                    false,
                    allow_result,
                    in_result_fn,
                );
            }
            ret_ty.unwrap_or(Type::Unknown)
        }
        Expr::Member {
            object,
            member,
            member_span,
        } => {
            let mut enum_name_opt: Option<SmolStr> = None;
            let mut enum_type_args: Vec<TypeRef> = Vec::new();
            if let Expr::Variable(enum_name) = &body.exprs[*object] {
                enum_name_opt = Some(enum_name.clone());
            } else if let Expr::TypeApply { callee, type_args } = &body.exprs[*object]
                && let Expr::Variable(enum_name) = &body.exprs[*callee]
            {
                enum_name_opt = Some(enum_name.clone());
                enum_type_args = type_args.clone();
            }
            if let Some(enum_name) = enum_name_opt
                && let Some(en) = enums.get(&enum_name)
                && let Some(params) = en.variants.get(member)
                && params.is_empty()
            {
                let resolved_args = resolve_type_args(
                    &enum_name,
                    &en.type_params,
                    &enum_type_args,
                    ctx,
                    errors,
                    span_from_range(body.expr_span(*object)),
                );
                return Type::Named(enum_name.clone(), resolved_args);
            }
            let object_ty = infer_expr(
                body,
                *object,
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                false,
                allow_result,
                in_result_fn,
            );
            let mut result = Type::Unknown;
            if let Type::Actor(_) = object_ty {
                errors.push(TypeError::ActorMemberAccess {
                    member: member.clone(),
                    span: span_from_range(*member_span),
                });
            } else if let Some(component_ty) = vector_component_type(&object_ty, member) {
                result = component_ty;
            } else if matches!(
                &object_ty,
                Type::Vec2 | Type::Vec3 | Type::Vec4 | Type::Quat | Type::Mat3 | Type::Mat4
            ) {
                errors.push(TypeError::UnknownMember {
                    object: type_label(&object_ty),
                    member: member.clone(),
                    span: span_from_range(*member_span),
                });
            } else if let Type::Named(class_name, class_args) = object_ty {
                if class_args.is_empty()
                    && let Some(field_ty) =
                        portable_named_field_type(class_name.as_str(), member.as_str())
                {
                    result = field_ty;
                } else if class_args.is_empty()
                    && is_portable_named_data_type_name(class_name.as_str())
                {
                    errors.push(TypeError::UnknownMember {
                        object: class_name.to_string(),
                        member: member.clone(),
                        span: span_from_range(*member_span),
                    });
                } else if interfaces.is_interface(&class_name) {
                    errors.push(TypeError::UnknownMember {
                        object: class_name.to_string(),
                        member: member.clone(),
                        span: span_from_range(*member_span),
                    });
                } else if let Some(class) = classes.get(&class_name) {
                    let subst = class_subst(class, &class_args);
                    if let Some(field_ty) = class.fields.get(member) {
                        result = substitute_type(field_ty, &subst);
                    } else if let Some(method) = class.methods.get(member) {
                        let _ = method;
                        result = Type::Unknown;
                    } else {
                        errors.push(TypeError::UnknownMember {
                            object: class_name.to_string(),
                            member: member.clone(),
                            span: span_from_range(*member_span),
                        });
                    }
                }
            }
            result
        }
        Expr::Index {
            object,
            index,
            index_span,
        } => {
            let object_ty = infer_expr(
                body,
                *object,
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                false,
                allow_result,
                in_result_fn,
            );
            let index_ty = infer_expr(
                body,
                *index,
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                false,
                allow_result,
                in_result_fn,
            );
            match object_ty {
                Type::List(inner_ty) | Type::Array(inner_ty, _) => {
                    if types_known(&Type::Integer, &index_ty) && index_ty != Type::Integer {
                        errors.push(TypeError::InvalidIndexType {
                            expected: "Integer".to_string(),
                            found: type_label(&index_ty),
                            span: span_from_range(*index_span),
                        });
                    }
                    (*inner_ty).clone()
                }
                Type::Map(key_ty, value_ty) => {
                    if types_known(&key_ty, &index_ty)
                        && !is_assignable(&key_ty, &index_ty, classes, interfaces)
                    {
                        errors.push(TypeError::InvalidIndexType {
                            expected: type_label(&key_ty),
                            found: type_label(&index_ty),
                            span: span_from_range(*index_span),
                        });
                    }
                    (*value_ty).clone()
                }
                Type::Unknown => Type::Unknown,
                _ => {
                    errors.push(TypeError::InvalidIndexTarget {
                        span: span_from_range(*index_span),
                    });
                    Type::Unknown
                }
            }
        }
        Expr::List(items) => infer_list(
            body,
            items,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
        ),
        Expr::Map(items) => infer_map(
            body,
            items,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
        ),
        Expr::StringInterp(parts) => {
            for part in parts {
                if let crate::hir::StringPart::Expr(expr) = part {
                    infer_expr(
                        body,
                        *expr,
                        ctx,
                        classes,
                        enums,
                        interfaces,
                        functions,
                        errors,
                        false,
                        allow_result,
                        in_result_fn,
                    );
                }
            }
            Type::String
        }
        Expr::Closure {
            params,
            body: closure_body,
        } => {
            ctx.enter_scope();
            for param in params {
                let ty = param
                    .ty
                    .as_ref()
                    .map(|t| type_from_ref_in_ctx(t, ctx))
                    .unwrap_or(Type::Unknown);
                ctx.declare(param.name.clone(), ty);
            }
            let _ = infer_expr(
                body,
                *closure_body,
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                false,
                allow_result,
                in_result_fn,
            );
            ctx.exit_scope();
            Type::Unknown
        }
    };
    ctx.record_expr(body, expr_id, ty.clone());
    if matches!(ty, Type::Pending(_)) && !allow_pending {
        errors.push(TypeError::PendingNotAwaited {
            span: span_from_range(body.expr_span(expr_id)),
            help: "`await` yields Result, and `fire` is for fire-and-forget. Use `await` or \
`fire` here."
                .to_string(),
        });
    }
    if matches!(ty, Type::Result(_, _)) && !allow_result {
        errors.push(TypeError::UnhandledResult {
            span: span_from_range(body.expr_span(expr_id)),
            help: "Handle with `??`, `match`, `ignore result`, `capture`, or return the \
Result from a Result-returning function."
                .to_string(),
        });
    }
    ty
}

pub(super) fn check_call_args(
    body: &Body,
    expr_id: Idx<Expr>,
    args: &Vec<crate::hir::Arg>,
    params: &Vec<(SmolStr, Type)>,
    ctx: &mut TypeContext,
    classes: &ClassIndex,
    enums: &EnumIndex,
    interfaces: &InterfaceIndex,
    functions: &FunctionIndex,
    errors: &mut Vec<TypeError>,
    enforce_named_args: bool,
    allow_result: bool,
    in_result_fn: bool,
) {
    if enforce_named_args && requires_named_args(params.len(), args) {
        let arg_spans =
            args.iter()
                .map(|arg| match arg {
                    crate::hir::Arg::Positional { span, .. }
                    | crate::hir::Arg::Named { span, .. } => span_from_range(*span),
                })
                .collect::<Vec<_>>();
        errors.push(TypeError::NamedArgsRequired {
            span: span_from_range(body.expr_span(expr_id)),
            param_names: params.iter().map(|(name, _)| name.clone()).collect(),
            arg_spans,
        });
    }

    if args
        .iter()
        .any(|arg| matches!(arg, crate::hir::Arg::Named { .. }))
    {
        let mut param_map = HashMap::new();
        for (name, ty) in params {
            param_map.insert(name.clone(), ty.clone());
        }
        for arg in args {
            if let crate::hir::Arg::Named {
                name,
                value,
                name_span,
                ..
            } = arg
            {
                let Some(expected) = param_map.get(name) else {
                    errors.push(TypeError::UnknownArgument {
                        name: name.clone(),
                        span: span_from_range(*name_span),
                    });
                    continue;
                };
                let found = infer_expr(
                    body,
                    *value,
                    ctx,
                    classes,
                    enums,
                    interfaces,
                    functions,
                    errors,
                    false,
                    allow_result,
                    in_result_fn,
                );
                if types_known(expected, &found)
                    && !is_assignable(expected, &found, classes, interfaces)
                {
                    errors.push(TypeError::ArgumentTypeMismatch {
                        name: name.clone(),
                        expected: type_label(expected),
                        found: type_label(&found),
                        span: span_from_range(*name_span),
                    });
                }
            }
        }
        if args.len() != params.len() {
            errors.push(TypeError::ArgumentCountMismatch {
                expected: params.len(),
                found: args.len(),
                span: span_from_range(body.expr_span(expr_id)),
            });
        }
        return;
    }

    if args.len() != params.len() {
        errors.push(TypeError::ArgumentCountMismatch {
            expected: params.len(),
            found: args.len(),
            span: span_from_range(body.expr_span(expr_id)),
        });
        return;
    }

    for (index, arg) in args.iter().enumerate() {
        let expected = &params[index].1;
        let (found, span) = match arg {
            crate::hir::Arg::Positional { value, span } => (
                infer_expr(
                    body,
                    *value,
                    ctx,
                    classes,
                    enums,
                    interfaces,
                    functions,
                    errors,
                    false,
                    allow_result,
                    in_result_fn,
                ),
                *span,
            ),
            crate::hir::Arg::Named { value, span, .. } => (
                infer_expr(
                    body,
                    *value,
                    ctx,
                    classes,
                    enums,
                    interfaces,
                    functions,
                    errors,
                    false,
                    allow_result,
                    in_result_fn,
                ),
                *span,
            ),
        };
        if types_known(expected, &found) && !is_assignable(expected, &found, classes, interfaces) {
            errors.push(TypeError::ArgumentTypeMismatch {
                name: params[index].0.clone(),
                expected: type_label(expected),
                found: type_label(&found),
                span: span_from_range(span),
            });
        }
    }
}

pub(super) fn builtin_allows_positional_args(name: &SmolStr) -> bool {
    name.as_str().starts_with("__wr_")
        || matches!(
            name.as_str(),
            "assert"
                | "vec2"
                | "vec3"
                | "vec4"
                | "quat"
                | "mat3_identity"
                | "mat3_cols"
                | "mat4_identity"
                | "mat4_cols"
                | "dot"
                | "length"
                | "normalize"
                | "cross"
                | "min"
                | "max"
                | "clamp"
                | "mix"
                | "abs"
                | "sign"
                | "floor"
                | "ceil"
                | "fract"
                | "sin"
                | "cos"
                | "sqrt"
                | "pow"
                | "distance"
                | "reflect"
                | "f32"
                | "i32"
                | "i64"
                | "u32"
                | "u64"
                | "capture"
        )
}

pub(super) fn call_named_arg_value(args: &[crate::hir::Arg], name: &str) -> Option<Idx<Expr>> {
    for arg in args {
        if let crate::hir::Arg::Named {
            name: arg_name,
            value,
            ..
        } = arg
            && arg_name.as_str() == name
        {
            return Some(*value);
        }
    }
    None
}

pub(super) fn infer_compute_builtin_call(
    body: &Body,
    expr_id: Idx<Expr>,
    name: &SmolStr,
    args: &Vec<crate::hir::Arg>,
    ctx: &mut TypeContext,
    classes: &ClassIndex,
    enums: &EnumIndex,
    interfaces: &InterfaceIndex,
    functions: &FunctionIndex,
    errors: &mut Vec<TypeError>,
    allow_result: bool,
    in_result_fn: bool,
) -> Option<Type> {
    if let Some(ret) = infer_legacy_query_builtin(
        body,
        expr_id,
        name,
        args,
        ctx,
        classes,
        enums,
        interfaces,
        functions,
        errors,
        allow_result,
        in_result_fn,
    ) {
        return Some(ret);
    }

    let span = span_from_range(body.expr_span(expr_id));
    match name.as_str() {
        "gpu_buffer_new" => {
            let params = vec![
                (SmolStr::new("length"), Type::Integer),
                (SmolStr::new("default_value"), Type::Unknown),
            ];
            check_call_args(
                body,
                expr_id,
                args,
                &params,
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                true,
                allow_result,
                in_result_fn,
            );
            let value_ty = call_named_arg_value(args, "default_value")
                .map(|value| {
                    infer_expr(
                        body,
                        value,
                        ctx,
                        classes,
                        enums,
                        interfaces,
                        functions,
                        errors,
                        false,
                        allow_result,
                        in_result_fn,
                    )
                })
                .unwrap_or(Type::Unknown);
            Some(Type::GpuBuffer(Box::new(value_ty)))
        }
        "gpu_buffer_len" => {
            let Some(buffer_value) = call_named_arg_value(args, "buffer") else {
                errors.push(TypeError::ArgumentCountMismatch {
                    expected: 1,
                    found: args.len(),
                    span,
                });
                return Some(Type::Unknown);
            };
            let buffer_ty = infer_expr(
                body,
                buffer_value,
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                false,
                allow_result,
                in_result_fn,
            );
            let params = vec![(SmolStr::new("buffer"), Type::Unknown)];
            check_call_args(
                body,
                expr_id,
                args,
                &params,
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                true,
                allow_result,
                in_result_fn,
            );
            if !matches!(buffer_ty, Type::GpuBuffer(_)) {
                errors.push(TypeError::ArgumentTypeMismatch {
                    name: SmolStr::new("buffer"),
                    expected: "GpuBuffer[unknown]".to_string(),
                    found: type_label(&buffer_ty),
                    span,
                });
                return Some(Type::Unknown);
            }
            Some(Type::Integer)
        }
        "gpu_buffer_get" => {
            let Some(buffer_value) = call_named_arg_value(args, "buffer") else {
                errors.push(TypeError::ArgumentCountMismatch {
                    expected: 2,
                    found: args.len(),
                    span,
                });
                return Some(Type::Unknown);
            };
            let buffer_ty = infer_expr(
                body,
                buffer_value,
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                false,
                allow_result,
                in_result_fn,
            );
            let Some(inner_ty) = (match buffer_ty {
                Type::GpuBuffer(inner) => Some(*inner),
                other => {
                    errors.push(TypeError::ArgumentTypeMismatch {
                        name: SmolStr::new("buffer"),
                        expected: "GpuBuffer[unknown]".to_string(),
                        found: type_label(&other),
                        span,
                    });
                    None
                }
            }) else {
                return Some(Type::Unknown);
            };
            let Some(index_expr) = call_named_arg_value(args, "index") else {
                errors.push(TypeError::ArgumentCountMismatch {
                    expected: 2,
                    found: args.len(),
                    span,
                });
                return Some(Type::Unknown);
            };
            let index_ty = infer_expr(
                body,
                index_expr,
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                false,
                allow_result,
                in_result_fn,
            );
            if !matches!(index_ty, Type::Unknown)
                && !matches!(
                    index_ty,
                    Type::Integer | Type::I32 | Type::U32 | Type::I64 | Type::U64
                )
            {
                errors.push(TypeError::ArgumentTypeMismatch {
                    name: SmolStr::new("index"),
                    expected: "Integer-like scalar".to_string(),
                    found: type_label(&index_ty),
                    span,
                });
            }
            let params = vec![
                (SmolStr::new("buffer"), Type::Unknown),
                (SmolStr::new("index"), Type::Unknown),
            ];
            check_call_args(
                body,
                expr_id,
                args,
                &params,
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                true,
                allow_result,
                in_result_fn,
            );
            Some(inner_ty)
        }
        "gpu_buffer_set" => {
            let Some(buffer_value) = call_named_arg_value(args, "buffer") else {
                errors.push(TypeError::ArgumentCountMismatch {
                    expected: 3,
                    found: args.len(),
                    span,
                });
                return Some(Type::Nil);
            };
            let buffer_ty = infer_expr(
                body,
                buffer_value,
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                false,
                allow_result,
                in_result_fn,
            );
            let Some(inner_ty) = (match buffer_ty {
                Type::GpuBuffer(inner) => Some(*inner),
                other => {
                    errors.push(TypeError::ArgumentTypeMismatch {
                        name: SmolStr::new("buffer"),
                        expected: "GpuBuffer[unknown]".to_string(),
                        found: type_label(&other),
                        span,
                    });
                    None
                }
            }) else {
                return Some(Type::Nil);
            };
            let Some(index_expr) = call_named_arg_value(args, "index") else {
                errors.push(TypeError::ArgumentCountMismatch {
                    expected: 3,
                    found: args.len(),
                    span,
                });
                return Some(Type::Nil);
            };
            let index_ty = infer_expr(
                body,
                index_expr,
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                false,
                allow_result,
                in_result_fn,
            );
            if !matches!(index_ty, Type::Unknown)
                && !matches!(
                    index_ty,
                    Type::Integer | Type::I32 | Type::U32 | Type::I64 | Type::U64
                )
            {
                errors.push(TypeError::ArgumentTypeMismatch {
                    name: SmolStr::new("index"),
                    expected: "Integer-like scalar".to_string(),
                    found: type_label(&index_ty),
                    span,
                });
            }
            let Some(value_expr) = call_named_arg_value(args, "value") else {
                errors.push(TypeError::ArgumentCountMismatch {
                    expected: 3,
                    found: args.len(),
                    span,
                });
                return Some(Type::Nil);
            };
            let value_ty = infer_expr(
                body,
                value_expr,
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                false,
                allow_result,
                in_result_fn,
            );
            if !matches!(inner_ty, Type::Unknown)
                && types_known(&inner_ty, &value_ty)
                && !is_assignable(&inner_ty, &value_ty, classes, interfaces)
            {
                errors.push(TypeError::ArgumentTypeMismatch {
                    name: SmolStr::new("value"),
                    expected: type_label(&inner_ty),
                    found: type_label(&value_ty),
                    span,
                });
            }
            let params = vec![
                (SmolStr::new("buffer"), Type::Unknown),
                (SmolStr::new("index"), Type::Unknown),
                (SmolStr::new("value"), inner_ty),
            ];
            check_call_args(
                body,
                expr_id,
                args,
                &params,
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                true,
                allow_result,
                in_result_fn,
            );
            Some(Type::Nil)
        }
        "gpu_atomic_i32_new" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[(SmolStr::new("initial"), Type::I32)],
            Type::GpuAtomicI32,
        ),
        "gpu_atomic_i32_drop" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[(SmolStr::new("atomic"), Type::GpuAtomicI32)],
            Type::Boolean,
        ),
        "gpu_atomic_i32_load" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[(SmolStr::new("atomic"), Type::GpuAtomicI32)],
            Type::I32,
        ),
        "gpu_atomic_i32_store" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("atomic"), Type::GpuAtomicI32),
                (SmolStr::new("value"), Type::I32),
            ],
            Type::Nil,
        ),
        "gpu_atomic_i32_fetch_add" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("atomic"), Type::GpuAtomicI32),
                (SmolStr::new("delta"), Type::I32),
            ],
            Type::I32,
        ),
        "gpu_atomic_u32_new" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[(SmolStr::new("initial"), Type::U32)],
            Type::GpuAtomicU32,
        ),
        "gpu_atomic_u32_drop" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[(SmolStr::new("atomic"), Type::GpuAtomicU32)],
            Type::Boolean,
        ),
        "gpu_atomic_u32_load" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[(SmolStr::new("atomic"), Type::GpuAtomicU32)],
            Type::U32,
        ),
        "gpu_atomic_u32_store" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("atomic"), Type::GpuAtomicU32),
                (SmolStr::new("value"), Type::U32),
            ],
            Type::Nil,
        ),
        "gpu_atomic_u32_fetch_add" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("atomic"), Type::GpuAtomicU32),
                (SmolStr::new("delta"), Type::U32),
            ],
            Type::U32,
        ),
        "gpu_schedule_deterministic" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[],
            Type::GpuDispatchSchedule,
        ),
        "gpu_schedule_reverse" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[],
            Type::GpuDispatchSchedule,
        ),
        "gpu_schedule_shuffle" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[(SmolStr::new("seed"), Type::U32)],
            Type::GpuDispatchSchedule,
        ),
        "gpu_schedule_workgroup_reverse" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[],
            Type::GpuDispatchSchedule,
        ),
        "gpu_schedule_workgroup_shuffle" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[(SmolStr::new("seed"), Type::U32)],
            Type::GpuDispatchSchedule,
        ),
        "gpu_schedule_round_robin_workgroups" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[],
            Type::GpuDispatchSchedule,
        ),
        "workgroup_barrier" => {
            errors.push(TypeError::UnsupportedComputeFeature {
                feature: "workgroup_barrier",
                span,
                help: "Barriered workgroup execution is the next virtual GPU cut; use data-parallel kernels plus atomics for now.".to_string(),
            });
            Some(Type::Nil)
        }
        "storage_barrier" => {
            errors.push(TypeError::UnsupportedComputeFeature {
                feature: "storage_barrier",
                span,
                help: "Storage barriers are not modeled in the CPU reference GPU yet; keep kernels order-independent or use explicit atomic coordination.".to_string(),
            });
            Some(Type::Nil)
        }
        "dispatch_compute" => {
            let Some(kernel_expr) = call_named_arg_value(args, "kernel") else {
                errors.push(TypeError::UnknownArgument {
                    name: SmolStr::new("kernel"),
                    span,
                });
                return Some(Type::Nil);
            };
            let Expr::Variable(kernel_name) = &body.exprs[kernel_expr] else {
                errors.push(TypeError::InvalidCallee {
                    span: span_from_range(body.expr_span(kernel_expr)),
                });
                return Some(Type::Nil);
            };
            let Some(kernel) = functions.get(kernel_name) else {
                errors.push(TypeError::InvalidCallee {
                    span: span_from_range(body.expr_span(kernel_expr)),
                });
                return Some(Type::Nil);
            };
            if !functions.is_kernel(kernel_name) {
                errors.push(TypeError::DispatchKernelMustBePortable {
                    callee: kernel_name.clone(),
                    span: span_from_range(body.expr_span(kernel_expr)),
                });
            }
            let mut params = vec![(SmolStr::new("kernel"), Type::Unknown)];
            params.extend([
                (SmolStr::new("workgroups_x"), Type::U32),
                (SmolStr::new("workgroups_y"), Type::U32),
                (SmolStr::new("workgroups_z"), Type::U32),
                (SmolStr::new("workgroup_size_x"), Type::U32),
                (SmolStr::new("workgroup_size_y"), Type::U32),
                (SmolStr::new("workgroup_size_z"), Type::U32),
            ]);
            if call_named_arg_value(args, "schedule").is_some() {
                params.push((SmolStr::new("schedule"), Type::GpuDispatchSchedule));
            }
            params.extend(kernel.params.clone());
            check_call_args(
                body,
                expr_id,
                args,
                &params,
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                true,
                allow_result,
                in_result_fn,
            );
            if kernel.ret != Type::Nil {
                errors.push(TypeError::ReturnTypeMismatch {
                    expected: "Nothing".to_string(),
                    found: type_label(&kernel.ret),
                    span: span_from_range(body.expr_span(kernel_expr)),
                });
            }
            Some(Type::Nil)
        }
        _ => None,
    }
}

pub(super) fn infer_exact_builtin_call(
    body: &Body,
    expr_id: Idx<Expr>,
    args: &Vec<crate::hir::Arg>,
    ctx: &mut TypeContext,
    classes: &ClassIndex,
    enums: &EnumIndex,
    interfaces: &InterfaceIndex,
    functions: &FunctionIndex,
    errors: &mut Vec<TypeError>,
    allow_result: bool,
    in_result_fn: bool,
    params: &[(SmolStr, Type)],
    ret: Type,
) -> Option<Type> {
    let params_vec = params.to_vec();
    check_call_args(
        body,
        expr_id,
        args,
        &params_vec,
        ctx,
        classes,
        enums,
        interfaces,
        functions,
        errors,
        true,
        allow_result,
        in_result_fn,
    );
    Some(ret.clone())
}

pub(super) fn infer_capture_builtin(
    body: &Body,
    expr_id: Idx<Expr>,
    args: &Vec<crate::hir::Arg>,
    ctx: &mut TypeContext,
    classes: &ClassIndex,
    enums: &EnumIndex,
    interfaces: &InterfaceIndex,
    functions: &FunctionIndex,
    errors: &mut Vec<TypeError>,
    allow_result: bool,
    in_result_fn: bool,
) -> Option<Type> {
    if ctx.in_portable_lane() && !ctx.in_portable_query_kernel_lane() {
        errors.push(TypeError::PortableHostCallForbidden {
            function: ctx.current_function_name(),
            callee: SmolStr::new("capture"),
            span: span_from_range(body.expr_span(expr_id)),
            help: "Captures are host-side execution boundaries; portable scene code must stay pure and capture-free.".to_string(),
        });
    }

    let params = vec![(SmolStr::new("scene"), Type::Unknown)];
    check_call_args(
        body,
        expr_id,
        args,
        &params,
        ctx,
        classes,
        enums,
        interfaces,
        functions,
        errors,
        false,
        allow_result,
        in_result_fn,
    );

    let target_expr = call_named_arg_value(args, "scene");
    if let Some(target_expr) = target_expr {
        let is_valid = match &body.exprs[target_expr] {
            Expr::Variable(name) => {
                ctx.resolve(name).is_none()
                    && (functions.is_field(name)
                        || functions.is_shape(name)
                        || functions.is_region(name))
            }
            _ => false,
        };
        if !is_valid {
            errors.push(TypeError::CaptureTargetMustBeFieldOrShape {
                span: span_from_range(body.expr_span(target_expr)),
                help: "Pass a top-level field, shape, or region declaration, for example `capture scene_shape` or `capture Highlands`.".to_string(),
            });
        }
    }

    Some(match target_expr {
        Some(target_expr) => match &body.exprs[target_expr] {
            Expr::Variable(name) if functions.is_region(name) => region_capture_type(),
            Expr::Variable(name) if functions.is_shape(name) => shape_capture_type(),
            Expr::Variable(name) if functions.is_field(name) => field_capture_type(),
            _ => Type::Unknown,
        },
        None => Type::Unknown,
    })
}

pub(super) fn direct_capture_target_name(body: &Body, expr_id: Idx<Expr>) -> Option<SmolStr> {
    let Expr::Call { callee, args, .. } = &body.exprs[expr_id] else {
        return None;
    };
    let Expr::Variable(name) = &body.exprs[*callee] else {
        return None;
    };
    if name.as_str() != "capture" {
        return None;
    }
    let scene_expr = call_named_arg_value(args, "scene")?;
    let Expr::Variable(target) = &body.exprs[scene_expr] else {
        return None;
    };
    Some(target.clone())
}

pub(super) fn infer_scene_backend_builtin(
    body: &Body,
    expr_id: Idx<Expr>,
    name: &SmolStr,
    args: &Vec<crate::hir::Arg>,
    ctx: &mut TypeContext,
    classes: &ClassIndex,
    enums: &EnumIndex,
    interfaces: &InterfaceIndex,
    functions: &FunctionIndex,
    errors: &mut Vec<TypeError>,
    allow_result: bool,
    in_result_fn: bool,
) -> Option<Type> {
    if ctx.in_portable_lane() && !ctx.in_portable_query_kernel_lane() {
        errors.push(TypeError::PortableHostCallForbidden {
            function: ctx.current_function_name(),
            callee: name.clone(),
            span: span_from_range(body.expr_span(expr_id)),
            help: "Bulk scene dispatch backends are host-side orchestration only.".to_string(),
        });
    }
    infer_exact_builtin_call(
        body,
        expr_id,
        args,
        ctx,
        classes,
        enums,
        interfaces,
        functions,
        errors,
        allow_result,
        in_result_fn,
        &[],
        dispatch_backend_type(),
    )
}

pub(super) fn infer_legacy_query_builtin(
    body: &Body,
    expr_id: Idx<Expr>,
    name: &SmolStr,
    args: &Vec<crate::hir::Arg>,
    ctx: &mut TypeContext,
    classes: &ClassIndex,
    enums: &EnumIndex,
    interfaces: &InterfaceIndex,
    functions: &FunctionIndex,
    errors: &mut Vec<TypeError>,
    allow_result: bool,
    in_result_fn: bool,
) -> Option<Type> {
    use crate::query_contract::{CaptureKind, QuerySurfaceKind};

    let candidates = legacy_query_contract_candidates(name.as_str());
    if candidates.is_empty() {
        return None;
    }
    if ctx.in_portable_lane() && !ctx.in_portable_query_kernel_lane() {
        errors.push(TypeError::PortableHostCallForbidden {
            function: ctx.current_function_name(),
            callee: name.clone(),
            span: span_from_range(body.expr_span(expr_id)),
            help: "Compatibility query aliases are execution boundaries. Prefer the family surface (`spatial.*`, `surface.*`, `participants.*`, or `support.*`) from host or query-kernel code.".to_string(),
        });
    }

    let capture_expr = call_named_arg_value(args, "capture");
    let surface = legacy_query_surface(&candidates, args);
    let capture_kind = match (surface, capture_expr) {
        (QuerySurfaceKind::WorldScalar | QuerySurfaceKind::WorldBatch, _) => CaptureKind::Region,
        (_, Some(capture_expr)) => infer_capture_kind_for_query_arg(
            body,
            capture_expr,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
        ),
        (_, None) => candidates
            .iter()
            .find_map(|descriptor| {
                (descriptor.surface == surface).then_some(descriptor.capture_kind)
            })
            .unwrap_or(CaptureKind::Field),
    };
    let Some(descriptor) = candidates
        .iter()
        .find(|descriptor| descriptor.surface == surface && descriptor.capture_kind == capture_kind)
        .copied()
    else {
        if let Some(capture_expr) = capture_expr {
            let expected = expected_legacy_query_capture_label(name.as_str(), surface)
                .unwrap_or("a supported capture");
            let found = infer_expr(
                body,
                capture_expr,
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                false,
                allow_result,
                in_result_fn,
            );
            errors.push(TypeError::ArgumentTypeMismatch {
                name: SmolStr::new("capture"),
                expected: expected.to_string(),
                found: type_label(&found),
                span: span_from_range(body.expr_span(capture_expr)),
            });
        }
        return Some(Type::Unknown);
    };

    let params = family_query_params(descriptor, args);
    infer_exact_builtin_call(
        body,
        expr_id,
        args,
        ctx,
        classes,
        enums,
        interfaces,
        functions,
        errors,
        allow_result,
        in_result_fn,
        &params,
        family_query_return_type(descriptor),
    )?;
    if let Some(capture_expr) = capture_expr {
        validate_family_query_capture_argument(
            body,
            capture_expr,
            descriptor,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
        );
    }
    if let Some(domain_expr) = call_named_arg_value(args, "domain") {
        validate_scene_domain_argument(
            body,
            domain_expr,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
        );
    }

    Some(family_query_return_type(descriptor))
}

pub(super) fn legacy_query_contract_candidates(
    legacy_builtin_name: &str,
) -> Vec<&'static crate::query_contract::QueryContractDescriptor> {
    crate::query_contract::query_execution_bindings()
        .iter()
        .filter(|binding| binding.legacy_builtin_name == legacy_builtin_name)
        .filter_map(|binding| crate::query_contract::query_contract(binding.contract_id))
        .collect()
}

pub(super) fn legacy_query_surface(
    candidates: &[&crate::query_contract::QueryContractDescriptor],
    args: &[crate::hir::Arg],
) -> crate::query_contract::QuerySurfaceKind {
    use crate::query_contract::{QueryCardinality, QuerySurfaceKind, QueryTargetKind};

    if candidates
        .iter()
        .any(|descriptor| descriptor.cardinality == QueryCardinality::Batch)
    {
        let target = if call_named_arg_value(args, "domain").is_some()
            || candidates
                .iter()
                .any(|descriptor| descriptor.surface == QuerySurfaceKind::WorldBatch)
        {
            QueryTargetKind::World
        } else {
            QueryTargetKind::Capture
        };
        return QuerySurfaceKind::from_axes(target, QueryCardinality::Batch);
    }
    if call_named_arg_value(args, "domain").is_some()
        || candidates
            .iter()
            .all(|descriptor| descriptor.surface == QuerySurfaceKind::WorldScalar)
    {
        return QuerySurfaceKind::WorldScalar;
    }
    QuerySurfaceKind::CaptureScalar
}

pub(super) fn expected_legacy_query_capture_label(
    legacy_builtin_name: &str,
    surface: crate::query_contract::QuerySurfaceKind,
) -> Option<&'static str> {
    let mut kinds = legacy_query_contract_candidates(legacy_builtin_name)
        .into_iter()
        .filter(|descriptor| descriptor.surface == surface)
        .map(|descriptor| descriptor.capture_kind)
        .collect::<Vec<_>>();
    kinds.sort();
    kinds.dedup();
    capture_kind_label(kinds.as_slice())
}

pub(super) fn query_family_object(
    body: &Body,
    object: Idx<Expr>,
    ctx: &mut TypeContext,
) -> Option<crate::query_contract::QueryFamilyId> {
    let Expr::Variable(name) = &body.exprs[object] else {
        return None;
    };
    if ctx.resolve(name).is_some() {
        return None;
    }
    let family = crate::query_contract::query_family_namespace(name.as_str())?;
    ctx.record_expr(body, object, Type::QueryFamily(family));
    Some(family)
}

pub(super) fn family_query_call_name(
    family: crate::query_contract::QueryFamilyId,
    member: &SmolStr,
) -> SmolStr {
    SmolStr::new(format!(
        "{}.{}",
        crate::query_contract::query_family_name(family),
        member
    ))
}

pub(super) fn infer_family_query_member_builtin(
    body: &Body,
    expr_id: Idx<Expr>,
    family: crate::query_contract::QueryFamilyId,
    member: &SmolStr,
    args: &Vec<crate::hir::Arg>,
    ctx: &mut TypeContext,
    classes: &ClassIndex,
    enums: &EnumIndex,
    interfaces: &InterfaceIndex,
    functions: &FunctionIndex,
    errors: &mut Vec<TypeError>,
    allow_result: bool,
    in_result_fn: bool,
) -> Option<Type> {
    use crate::query_contract::{
        QueryCardinality, QueryFamilyCallSurface, QuerySurfaceKind, QueryTargetKind,
    };

    let family_member = crate::query_contract::query_family_member(family, member.as_str())?;
    let query_name = family_query_call_name(family, member);
    if ctx.in_portable_lane() && !ctx.in_portable_query_kernel_lane() {
        errors.push(TypeError::PortableHostCallForbidden {
            function: ctx.current_function_name(),
            callee: query_name.clone(),
            span: span_from_range(body.expr_span(expr_id)),
            help: "Query-family calls are execution boundaries. Capture the scene first, then issue the query from host or query-kernel code.".to_string(),
        });
    }

    let capture_expr = call_named_arg_value(args, "capture");
    let cardinality = match family_member.call_surface {
        QueryFamilyCallSurface::Batch => QueryCardinality::Batch,
        QueryFamilyCallSurface::Scalar => QueryCardinality::Scalar,
    };
    let target = if call_named_arg_value(args, "domain").is_some() {
        QueryTargetKind::World
    } else {
        QueryTargetKind::Capture
    };
    let surface = QuerySurfaceKind::from_axes(target, cardinality);
    let capture_kind = match (surface, capture_expr) {
        (QuerySurfaceKind::WorldScalar | QuerySurfaceKind::WorldBatch, _) => {
            crate::query_contract::CaptureKind::Region
        }
        (_, Some(capture_expr)) => infer_capture_kind_for_query_arg(
            body,
            capture_expr,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
        ),
        (_, None) => crate::query_contract::CaptureKind::Field,
    };
    let (descriptor, _binding) =
        match crate::query_contract::query_contract_bundle_for_family_member_internal(
            family,
            member.as_str(),
            surface,
            capture_kind,
        ) {
            Some(bundle) => bundle,
            None => {
                if let Some(capture_expr) = capture_expr {
                    let expected = expected_family_query_capture_label(
                        family_member.family,
                        family_member.question,
                        surface,
                    )
                    .unwrap_or("a supported capture");
                    let found = infer_expr(
                        body,
                        capture_expr,
                        ctx,
                        classes,
                        enums,
                        interfaces,
                        functions,
                        errors,
                        false,
                        allow_result,
                        in_result_fn,
                    );
                    errors.push(TypeError::ArgumentTypeMismatch {
                        name: SmolStr::new("capture"),
                        expected: expected.to_string(),
                        found: type_label(&found),
                        span: span_from_range(body.expr_span(capture_expr)),
                    });
                }
                return Some(Type::Unknown);
            }
        };
    let params = family_query_params(descriptor, args);
    infer_exact_builtin_call(
        body,
        expr_id,
        args,
        ctx,
        classes,
        enums,
        interfaces,
        functions,
        errors,
        allow_result,
        in_result_fn,
        &params,
        family_query_return_type(descriptor),
    )?;

    if let Some(capture_expr) = capture_expr {
        validate_family_query_capture_argument(
            body,
            capture_expr,
            descriptor,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
        );
    }
    if let Some(domain_expr) = call_named_arg_value(args, "domain") {
        validate_scene_domain_argument(
            body,
            domain_expr,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
        );
    }

    Some(family_query_return_type(descriptor))
}

pub(super) fn infer_capture_kind_for_query_arg(
    body: &Body,
    capture_expr: Idx<Expr>,
    ctx: &mut TypeContext,
    classes: &ClassIndex,
    enums: &EnumIndex,
    interfaces: &InterfaceIndex,
    functions: &FunctionIndex,
    errors: &mut Vec<TypeError>,
    allow_result: bool,
    in_result_fn: bool,
) -> crate::query_contract::CaptureKind {
    if let Some(target) = direct_capture_target_name(body, capture_expr) {
        if functions.is_shape(&target) {
            return crate::query_contract::CaptureKind::Shape;
        }
        if functions.is_region(&target) {
            return crate::query_contract::CaptureKind::Region;
        }
        return crate::query_contract::CaptureKind::Field;
    }
    let found = infer_expr(
        body,
        capture_expr,
        ctx,
        classes,
        enums,
        interfaces,
        functions,
        errors,
        false,
        allow_result,
        in_result_fn,
    );
    match found {
        Type::Named(name, _) if name.as_str() == "ShapeCapture" => {
            crate::query_contract::CaptureKind::Shape
        }
        Type::Named(name, _) if name.as_str() == "RegionCapture" => {
            crate::query_contract::CaptureKind::Region
        }
        _ => crate::query_contract::CaptureKind::Field,
    }
}

pub(super) fn family_query_params(
    descriptor: &crate::query_contract::QueryContractDescriptor,
    args: &Vec<crate::hir::Arg>,
) -> Vec<(SmolStr, Type)> {
    use crate::query_contract::{QueryCardinality, QueryTargetKind};

    let mut params = Vec::new();
    let capture_ty = match descriptor.target {
        QueryTargetKind::World => region_capture_type(),
        QueryTargetKind::Capture => Type::Unknown,
    };
    params.push((SmolStr::new("capture"), capture_ty));
    if descriptor.domain_contract.is_some() {
        params.push((SmolStr::new("domain"), scene_domain_type()));
    }
    match descriptor.cardinality {
        QueryCardinality::Batch => {
            if let Some(item_arg) = batch_item_arg_name(descriptor.item_kind) {
                params.push((
                    SmolStr::new(item_arg),
                    Type::List(Box::new(batch_item_type(descriptor.item_kind))),
                ));
            }
            params.push((SmolStr::new("backend"), dispatch_backend_type()));
        }
        QueryCardinality::Scalar => {
            if let Some((item_arg, item_ty)) = scalar_item_param(descriptor.item_kind) {
                params.push((SmolStr::new(item_arg), item_ty));
            }
            if descriptor.target == QueryTargetKind::World
                && call_named_arg_value(args, "backend").is_some()
            {
                params.push((SmolStr::new("backend"), dispatch_backend_type()));
            }
        }
    }
    params
}

pub(super) fn scalar_item_param(
    kind: crate::query_contract::QueryItemKind,
) -> Option<(&'static str, Type)> {
    use crate::query_contract::QueryItemKind;
    match kind {
        QueryItemKind::Unit => None,
        QueryItemKind::PointQuery => Some(("point", Type::Vec3)),
        QueryItemKind::PointDirectionQuery => {
            Some(("sample", portable_named_type("PointDirectionQuery")))
        }
        QueryItemKind::RayQuery => Some(("ray", portable_named_type("RayQuery"))),
        QueryItemKind::Hit3 => Some(("hit", portable_named_type("Hit3"))),
    }
}

pub(super) fn batch_item_arg_name(
    kind: crate::query_contract::QueryItemKind,
) -> Option<&'static str> {
    use crate::query_contract::QueryItemKind;
    match kind {
        QueryItemKind::PointQuery => Some("points"),
        QueryItemKind::RayQuery => Some("rays"),
        QueryItemKind::Hit3 => Some("hits"),
        QueryItemKind::PointDirectionQuery => Some("samples"),
        QueryItemKind::Unit => Some("items"),
    }
}

pub(super) fn batch_item_type(kind: crate::query_contract::QueryItemKind) -> Type {
    use crate::query_contract::QueryItemKind;
    match kind {
        QueryItemKind::PointQuery => portable_named_type("PointQuery"),
        QueryItemKind::PointDirectionQuery => portable_named_type("PointDirectionQuery"),
        QueryItemKind::RayQuery => portable_named_type("RayQuery"),
        QueryItemKind::Hit3 => portable_named_type("Hit3"),
        QueryItemKind::Unit => portable_named_type("UnitQuery"),
    }
}

pub(super) fn family_query_return_type(
    descriptor: &crate::query_contract::QueryContractDescriptor,
) -> Type {
    use crate::query_contract::{QueryCardinality, QueryResultKind};

    let result = match descriptor.result_kind {
        QueryResultKind::DistanceResult if descriptor.cardinality == QueryCardinality::Scalar => {
            Type::F32
        }
        QueryResultKind::NormalResult if descriptor.cardinality == QueryCardinality::Scalar => {
            Type::Vec3
        }
        QueryResultKind::RadianceResult => Type::Vec3,
        QueryResultKind::MediumResult => portable_named_type("Medium"),
        QueryResultKind::DistanceResult => portable_named_type("DistanceResult"),
        QueryResultKind::NormalResult => portable_named_type("NormalResult"),
        QueryResultKind::SupportSummaryResult => portable_named_type("SupportSummaryResult"),
        QueryResultKind::Hit3 => portable_named_type("Hit3"),
        QueryResultKind::Surface => portable_named_type("Surface"),
        QueryResultKind::OcclusionResult => portable_named_type("OcclusionResult"),
    };

    if descriptor.cardinality == QueryCardinality::Batch {
        Type::List(Box::new(result))
    } else {
        result
    }
}

pub(super) fn validate_family_query_capture_argument(
    body: &Body,
    capture_expr: Idx<Expr>,
    descriptor: &crate::query_contract::QueryContractDescriptor,
    ctx: &mut TypeContext,
    classes: &ClassIndex,
    enums: &EnumIndex,
    interfaces: &InterfaceIndex,
    functions: &FunctionIndex,
    errors: &mut Vec<TypeError>,
    allow_result: bool,
    in_result_fn: bool,
) {
    use crate::query_contract::{CaptureKind, QueryTargetKind};

    if descriptor.target == QueryTargetKind::World {
        validate_region_capture_argument(
            body,
            capture_expr,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
        );
        return;
    }

    let found = infer_expr(
        body,
        capture_expr,
        ctx,
        classes,
        enums,
        interfaces,
        functions,
        errors,
        false,
        allow_result,
        in_result_fn,
    );
    if let Some(target) = direct_capture_target_name(body, capture_expr) {
        let actual = if functions.is_shape(&target) {
            CaptureKind::Shape
        } else if functions.is_region(&target) {
            CaptureKind::Region
        } else {
            CaptureKind::Field
        };
        if actual != descriptor.capture_kind {
            errors.push(TypeError::ArgumentTypeMismatch {
                name: SmolStr::new("capture"),
                expected: expected_capture_label(descriptor.capture_kind).to_string(),
                found: type_label(&found),
                span: span_from_range(body.expr_span(capture_expr)),
            });
        }
        return;
    }

    let expected = match descriptor.capture_kind {
        CaptureKind::Field => field_capture_type(),
        CaptureKind::Shape => shape_capture_type(),
        CaptureKind::Region => region_capture_type(),
    };
    if found != Type::Unknown && !is_assignable(&expected, &found, classes, interfaces) {
        errors.push(TypeError::ArgumentTypeMismatch {
            name: SmolStr::new("capture"),
            expected: expected_capture_label(descriptor.capture_kind).to_string(),
            found: type_label(&found),
            span: span_from_range(body.expr_span(capture_expr)),
        });
    } else if descriptor.capture_kind == CaptureKind::Region {
        errors.push(TypeError::ArgumentTypeMismatch {
            name: SmolStr::new("capture"),
            expected: expected_capture_label(descriptor.capture_kind).to_string(),
            found: type_label(&found),
            span: span_from_range(body.expr_span(capture_expr)),
        });
    }
}

pub(super) fn expected_capture_label(
    capture_kind: crate::query_contract::CaptureKind,
) -> &'static str {
    match capture_kind {
        crate::query_contract::CaptureKind::Field => "FieldCapture",
        crate::query_contract::CaptureKind::Shape => "ShapeCapture",
        crate::query_contract::CaptureKind::Region => "RegionCapture",
    }
}

pub(super) fn expected_family_query_capture_label(
    family: crate::query_contract::QueryFamilyId,
    question: crate::query_contract::QueryQuestionId,
    surface: crate::query_contract::QuerySurfaceKind,
) -> Option<&'static str> {
    let mut kinds = crate::query_contract::query_contracts()
        .iter()
        .filter(|descriptor| {
            descriptor.family == family
                && descriptor.question == question
                && descriptor.surface == surface
        })
        .map(|descriptor| descriptor.capture_kind)
        .collect::<Vec<_>>();
    kinds.sort();
    kinds.dedup();
    capture_kind_label(kinds.as_slice())
}

pub(super) fn capture_kind_label(
    kinds: &[crate::query_contract::CaptureKind],
) -> Option<&'static str> {
    use crate::query_contract::CaptureKind;

    match kinds {
        [CaptureKind::Field] => Some("FieldCapture"),
        [CaptureKind::Shape] => Some("ShapeCapture"),
        [CaptureKind::Region] => Some("RegionCapture"),
        [CaptureKind::Field, CaptureKind::Shape] => Some("FieldCapture or ShapeCapture"),
        _ => None,
    }
}

pub(super) fn validate_region_capture_argument(
    body: &Body,
    capture_expr: Idx<Expr>,
    ctx: &mut TypeContext,
    classes: &ClassIndex,
    enums: &EnumIndex,
    interfaces: &InterfaceIndex,
    functions: &FunctionIndex,
    errors: &mut Vec<TypeError>,
    allow_result: bool,
    in_result_fn: bool,
) {
    let found = infer_expr(
        body,
        capture_expr,
        ctx,
        classes,
        enums,
        interfaces,
        functions,
        errors,
        false,
        allow_result,
        in_result_fn,
    );
    if let Some(target) = direct_capture_target_name(body, capture_expr) {
        if !functions.is_region(&target) {
            errors.push(TypeError::ArgumentTypeMismatch {
                name: SmolStr::new("capture"),
                expected: "RegionCapture".to_string(),
                found: type_label(&found),
                span: span_from_range(body.expr_span(capture_expr)),
            });
        }
    } else if !is_region_capture_type(&found) && found != Type::Unknown {
        errors.push(TypeError::ArgumentTypeMismatch {
            name: SmolStr::new("capture"),
            expected: "RegionCapture".to_string(),
            found: type_label(&found),
            span: span_from_range(body.expr_span(capture_expr)),
        });
    }
}

pub(super) fn validate_scene_domain_argument(
    body: &Body,
    domain_expr: Idx<Expr>,
    ctx: &mut TypeContext,
    classes: &ClassIndex,
    enums: &EnumIndex,
    interfaces: &InterfaceIndex,
    functions: &FunctionIndex,
    errors: &mut Vec<TypeError>,
    allow_result: bool,
    in_result_fn: bool,
) {
    let found = infer_expr(
        body,
        domain_expr,
        ctx,
        classes,
        enums,
        interfaces,
        functions,
        errors,
        false,
        allow_result,
        in_result_fn,
    );
    if found != Type::Unknown && !is_assignable(&scene_domain_type(), &found, classes, interfaces) {
        errors.push(TypeError::ArgumentTypeMismatch {
            name: SmolStr::new("domain"),
            expected: "SceneDomain".to_string(),
            found: type_label(&found),
            span: span_from_range(body.expr_span(domain_expr)),
        });
    }
}

pub(super) fn field_capture_type() -> Type {
    portable_named_type("FieldCapture")
}

pub(super) fn shape_capture_type() -> Type {
    portable_named_type("ShapeCapture")
}

pub(super) fn region_capture_type() -> Type {
    portable_named_type("RegionCapture")
}

pub(super) fn detail_tier_type() -> Type {
    portable_named_type("DetailTier")
}

pub(super) fn is_region_capture_type(ty: &Type) -> bool {
    *ty == region_capture_type()
}

pub(super) fn dispatch_backend_type() -> Type {
    portable_named_type("DispatchBackend")
}

pub(super) fn scene_domain_type() -> Type {
    portable_named_type("SceneDomain")
}

pub(super) fn infer_math_builtin_call(
    body: &Body,
    expr_id: Idx<Expr>,
    name: &SmolStr,
    args: &Vec<crate::hir::Arg>,
    ctx: &mut TypeContext,
    classes: &ClassIndex,
    enums: &EnumIndex,
    interfaces: &InterfaceIndex,
    functions: &FunctionIndex,
    errors: &mut Vec<TypeError>,
    allow_result: bool,
    in_result_fn: bool,
) -> Option<Type> {
    let span = span_from_range(body.expr_span(expr_id));
    match name.as_str() {
        "vec2" => {
            let params = vec![
                (SmolStr::new("x"), Type::F32),
                (SmolStr::new("y"), Type::F32),
            ];
            check_call_args(
                body,
                expr_id,
                args,
                &params,
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                false,
                allow_result,
                in_result_fn,
            );
            Some(Type::Vec2)
        }
        "vec3" => {
            let params = vec![
                (SmolStr::new("x"), Type::F32),
                (SmolStr::new("y"), Type::F32),
                (SmolStr::new("z"), Type::F32),
            ];
            check_call_args(
                body,
                expr_id,
                args,
                &params,
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                false,
                allow_result,
                in_result_fn,
            );
            Some(Type::Vec3)
        }
        "vec4" => {
            let params = vec![
                (SmolStr::new("x"), Type::F32),
                (SmolStr::new("y"), Type::F32),
                (SmolStr::new("z"), Type::F32),
                (SmolStr::new("w"), Type::F32),
            ];
            check_call_args(
                body,
                expr_id,
                args,
                &params,
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                false,
                allow_result,
                in_result_fn,
            );
            Some(Type::Vec4)
        }
        "quat" => {
            let params = vec![
                (SmolStr::new("x"), Type::F32),
                (SmolStr::new("y"), Type::F32),
                (SmolStr::new("z"), Type::F32),
                (SmolStr::new("w"), Type::F32),
            ];
            check_call_args(
                body,
                expr_id,
                args,
                &params,
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                false,
                allow_result,
                in_result_fn,
            );
            Some(Type::Quat)
        }
        "mat3_identity" => {
            if args.len() != 0 {
                errors.push(TypeError::ArgumentCountMismatch {
                    expected: 0,
                    found: args.len(),
                    span,
                });
            }
            Some(Type::Mat3)
        }
        "mat3_cols" => {
            let params = vec![
                (SmolStr::new("c0"), Type::Vec3),
                (SmolStr::new("c1"), Type::Vec3),
                (SmolStr::new("c2"), Type::Vec3),
            ];
            check_call_args(
                body,
                expr_id,
                args,
                &params,
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                false,
                allow_result,
                in_result_fn,
            );
            Some(Type::Mat3)
        }
        "mat4_identity" => {
            if args.len() != 0 {
                errors.push(TypeError::ArgumentCountMismatch {
                    expected: 0,
                    found: args.len(),
                    span,
                });
            }
            Some(Type::Mat4)
        }
        "mat4_cols" => {
            let params = vec![
                (SmolStr::new("c0"), Type::Vec4),
                (SmolStr::new("c1"), Type::Vec4),
                (SmolStr::new("c2"), Type::Vec4),
                (SmolStr::new("c3"), Type::Vec4),
            ];
            check_call_args(
                body,
                expr_id,
                args,
                &params,
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                false,
                allow_result,
                in_result_fn,
            );
            Some(Type::Mat4)
        }
        "bounds2" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("min"), Type::Vec2),
                (SmolStr::new("max"), Type::Vec2),
            ],
            portable_named_type("Bounds2"),
        ),
        "bounds3" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("min"), Type::Vec3),
                (SmolStr::new("max"), Type::Vec3),
            ],
            portable_named_type("Bounds3"),
        ),
        "ray3" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("origin"), Type::Vec3),
                (SmolStr::new("direction"), Type::Vec3),
            ],
            portable_named_type("Ray3"),
        ),
        "transform3" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("matrix"), Type::Mat4),
                (SmolStr::new("inverse"), Type::Mat4),
            ],
            portable_named_type("Transform3"),
        ),
        "transform3_identity" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[],
            portable_named_type("Transform3"),
        ),
        "dot" => {
            if args.len() != 2 {
                errors.push(TypeError::ArgumentCountMismatch {
                    expected: 2,
                    found: args.len(),
                    span,
                });
                return Some(Type::Unknown);
            }
            let left_ty = infer_call_arg_type(
                body,
                &args[0],
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                allow_result,
                in_result_fn,
            );
            let right_ty = infer_call_arg_type(
                body,
                &args[1],
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                allow_result,
                in_result_fn,
            );
            if same_vector_like_kind(&left_ty, &right_ty).is_none() {
                push_math_builtin_arg_mismatch(
                    "left",
                    &left_ty,
                    args,
                    0,
                    "Vec2, Vec3, Vec4, or Quat",
                    errors,
                );
                push_math_builtin_arg_mismatch(
                    "right",
                    &right_ty,
                    args,
                    1,
                    "Vec2, Vec3, Vec4, or Quat",
                    errors,
                );
                return Some(Type::Unknown);
            }
            Some(Type::F32)
        }
        "bounds2_center" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[(SmolStr::new("bounds"), portable_named_type("Bounds2"))],
            Type::Vec2,
        ),
        "bounds2_size" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[(SmolStr::new("bounds"), portable_named_type("Bounds2"))],
            Type::Vec2,
        ),
        "bounds3_center" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[(SmolStr::new("bounds"), portable_named_type("Bounds3"))],
            Type::Vec3,
        ),
        "bounds3_size" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[(SmolStr::new("bounds"), portable_named_type("Bounds3"))],
            Type::Vec3,
        ),
        "length" | "normalize" => {
            if args.len() != 1 {
                errors.push(TypeError::ArgumentCountMismatch {
                    expected: 1,
                    found: args.len(),
                    span,
                });
                return Some(Type::Unknown);
            }
            let value_ty = infer_call_arg_type(
                body,
                &args[0],
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                allow_result,
                in_result_fn,
            );
            if !is_vector_like_type(&value_ty) {
                push_math_builtin_arg_mismatch(
                    "value",
                    &value_ty,
                    args,
                    0,
                    "Vec2, Vec3, Vec4, or Quat",
                    errors,
                );
                return Some(Type::Unknown);
            }
            Some(if name.as_str() == "length" {
                Type::F32
            } else {
                value_ty
            })
        }
        "cross" => {
            let params = vec![
                (SmolStr::new("left"), Type::Vec3),
                (SmolStr::new("right"), Type::Vec3),
            ];
            check_call_args(
                body,
                expr_id,
                args,
                &params,
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                false,
                allow_result,
                in_result_fn,
            );
            Some(Type::Vec3)
        }
        "distance" | "reflect" => {
            if args.len() != 2 {
                errors.push(TypeError::ArgumentCountMismatch {
                    expected: 2,
                    found: args.len(),
                    span,
                });
                return Some(Type::Unknown);
            }
            let left_ty = infer_call_arg_type(
                body,
                &args[0],
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                allow_result,
                in_result_fn,
            );
            let right_ty = infer_call_arg_type(
                body,
                &args[1],
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                allow_result,
                in_result_fn,
            );
            if !(is_vector_only_type(&left_ty) && same_vector_kind(&left_ty, &right_ty)) {
                push_math_builtin_arg_mismatch(
                    "left",
                    &left_ty,
                    args,
                    0,
                    "matching Vec2, Vec3, or Vec4 operands",
                    errors,
                );
                push_math_builtin_arg_mismatch(
                    "right",
                    &right_ty,
                    args,
                    1,
                    "matching Vec2, Vec3, or Vec4 operands",
                    errors,
                );
                return Some(Type::Unknown);
            }
            if name.as_str() == "distance" {
                Some(Type::F32)
            } else if is_vector_only_type(&left_ty) {
                Some(left_ty)
            } else {
                push_math_builtin_arg_mismatch(
                    "left",
                    &left_ty,
                    args,
                    0,
                    "Vec2, Vec3, or Vec4",
                    errors,
                );
                push_math_builtin_arg_mismatch(
                    "right",
                    &right_ty,
                    args,
                    1,
                    "Vec2, Vec3, or Vec4",
                    errors,
                );
                Some(Type::Unknown)
            }
        }
        "transform_point" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("transform"), portable_named_type("Transform3")),
                (SmolStr::new("point"), Type::Vec3),
            ],
            Type::Vec3,
        ),
        "transform_vector" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("transform"), portable_named_type("Transform3")),
                (SmolStr::new("vector"), Type::Vec3),
            ],
            Type::Vec3,
        ),
        "transform_normal" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("transform"), portable_named_type("Transform3")),
                (SmolStr::new("normal"), Type::Vec3),
            ],
            Type::Vec3,
        ),
        "compose_transform3" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("left"), portable_named_type("Transform3")),
                (SmolStr::new("right"), portable_named_type("Transform3")),
            ],
            portable_named_type("Transform3"),
        ),
        "inverse_transform3" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[(SmolStr::new("transform"), portable_named_type("Transform3"))],
            portable_named_type("Transform3"),
        ),
        "rounded_box" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("p"), Type::Vec3),
                (SmolStr::new("half"), Type::Vec3),
                (SmolStr::new("radius"), Type::F32),
            ],
            Type::F32,
        ),
        "ellipsoid" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("p"), Type::Vec3),
                (SmolStr::new("radii"), Type::Vec3),
            ],
            Type::F32,
        ),
        "cone" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("p"), Type::Vec3),
                (SmolStr::new("radius"), Type::F32),
                (SmolStr::new("half_height"), Type::F32),
            ],
            Type::F32,
        ),
        "capped_cone" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("p"), Type::Vec3),
                (SmolStr::new("radius_bottom"), Type::F32),
                (SmolStr::new("radius_top"), Type::F32),
                (SmolStr::new("half_height"), Type::F32),
            ],
            Type::F32,
        ),
        "box_frame" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("p"), Type::Vec3),
                (SmolStr::new("half"), Type::Vec3),
                (SmolStr::new("thickness"), Type::F32),
            ],
            Type::F32,
        ),
        "slab" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("p"), Type::Vec3),
                (SmolStr::new("thickness"), Type::F32),
            ],
            Type::F32,
        ),
        "triangle_prism" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("p"), Type::Vec3),
                (SmolStr::new("half"), Type::Vec2),
                (SmolStr::new("half_height"), Type::F32),
            ],
            Type::F32,
        ),
        "hex_prism" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("p"), Type::Vec3),
                (SmolStr::new("half"), Type::Vec2),
                (SmolStr::new("half_height"), Type::F32),
            ],
            Type::F32,
        ),
        "field_union" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("left"), Type::F32),
                (SmolStr::new("right"), Type::F32),
            ],
            Type::F32,
        ),
        "field_intersection" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("left"), Type::F32),
                (SmolStr::new("right"), Type::F32),
            ],
            Type::F32,
        ),
        "field_subtract" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("left"), Type::F32),
                (SmolStr::new("right"), Type::F32),
            ],
            Type::F32,
        ),
        "field_translate_point" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("translate"), Type::Vec3),
                (SmolStr::new("point"), Type::Vec3),
            ],
            Type::Vec3,
        ),
        "field_rotate_point" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("rotate"), Type::Vec3),
                (SmolStr::new("point"), Type::Vec3),
            ],
            Type::Vec3,
        ),
        "field_uniform_scale_point" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("scale"), Type::F32),
                (SmolStr::new("point"), Type::Vec3),
            ],
            Type::Vec3,
        ),
        "field_affine_transform_point" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("transform"), Type::Vec3),
                (SmolStr::new("point"), Type::Vec3),
            ],
            Type::Vec3,
        ),
        "field_warp_point" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("warp"), Type::Vec3),
                (SmolStr::new("point"), Type::Vec3),
            ],
            Type::Vec3,
        ),
        "field_repeat_linear_point" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("repeat"), Type::Vec3),
                (SmolStr::new("point"), Type::Vec3),
            ],
            Type::Vec3,
        ),
        "field_repeat_grid_point" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("repeat"), Type::Vec3),
                (SmolStr::new("point"), Type::Vec3),
            ],
            Type::Vec3,
        ),
        "field_radial_repeat_point" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("radial"), Type::Vec3),
                (SmolStr::new("point"), Type::Vec3),
            ],
            Type::Vec3,
        ),
        "field_mirror_array_point" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("mirror"), Type::Vec3),
                (SmolStr::new("point"), Type::Vec3),
            ],
            Type::Vec3,
        ),
        "field_instance_array_point" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("instance"), portable_named_type("Transform3")),
                (SmolStr::new("point"), Type::Vec3),
            ],
            Type::Vec3,
        ),
        "field_smooth_union" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("smoothing"), Type::F32),
                (SmolStr::new("left"), Type::F32),
                (SmolStr::new("right"), Type::F32),
            ],
            Type::F32,
        ),
        "field_smooth_intersection" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("smoothing"), Type::F32),
                (SmolStr::new("left"), Type::F32),
                (SmolStr::new("right"), Type::F32),
            ],
            Type::F32,
        ),
        "field_smooth_subtract" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("smoothing"), Type::F32),
                (SmolStr::new("left"), Type::F32),
                (SmolStr::new("right"), Type::F32),
            ],
            Type::F32,
        ),
        "field_bend_point" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("bend"), Type::Vec3),
                (SmolStr::new("point"), Type::Vec3),
            ],
            Type::Vec3,
        ),
        "field_twist_point" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("twist"), Type::Vec3),
                (SmolStr::new("point"), Type::Vec3),
            ],
            Type::Vec3,
        ),
        "field_taper_point" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("taper"), Type::Vec3),
                (SmolStr::new("point"), Type::Vec3),
            ],
            Type::Vec3,
        ),
        "field_displace_point" => infer_exact_builtin_call(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            &[
                (SmolStr::new("displace"), Type::Vec3),
                (SmolStr::new("point"), Type::Vec3),
            ],
            Type::Vec3,
        ),
        "capture" => infer_capture_builtin(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
        ),
        "dispatch_backend_cpu"
        | "dispatch_backend_virtual_gpu"
        | "dispatch_backend_wgsl"
        | "dispatch_backend_auto" => infer_scene_backend_builtin(
            body,
            expr_id,
            name,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
        ),
        "min" | "max" | "pow" => infer_componentwise_binary_builtin(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
        ),
        "clamp" | "mix" => infer_componentwise_ternary_builtin(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
        ),
        "abs" | "sign" | "floor" | "ceil" | "fract" | "sin" | "cos" | "sqrt" => {
            infer_componentwise_unary_builtin(
                body,
                expr_id,
                args,
                ctx,
                classes,
                enums,
                interfaces,
                functions,
                errors,
                allow_result,
                in_result_fn,
            )
        }
        "f32" => infer_scalar_cast_builtin(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            Type::F32,
        ),
        "i32" => infer_scalar_cast_builtin(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            Type::I32,
        ),
        "i64" => infer_scalar_cast_builtin(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            Type::I64,
        ),
        "u32" => infer_scalar_cast_builtin(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            Type::U32,
        ),
        "u64" => infer_scalar_cast_builtin(
            body,
            expr_id,
            args,
            ctx,
            classes,
            enums,
            interfaces,
            functions,
            errors,
            allow_result,
            in_result_fn,
            Type::U64,
        ),
        _ => None,
    }
}

pub(super) fn infer_call_arg_type(
    body: &Body,
    arg: &crate::hir::Arg,
    ctx: &mut TypeContext,
    classes: &ClassIndex,
    enums: &EnumIndex,
    interfaces: &InterfaceIndex,
    functions: &FunctionIndex,
    errors: &mut Vec<TypeError>,
    allow_result: bool,
    in_result_fn: bool,
) -> Type {
    let value = match arg {
        crate::hir::Arg::Positional { value, .. } | crate::hir::Arg::Named { value, .. } => *value,
    };
    infer_expr(
        body,
        value,
        ctx,
        classes,
        enums,
        interfaces,
        functions,
        errors,
        false,
        allow_result,
        in_result_fn,
    )
}

pub(super) fn infer_componentwise_unary_builtin(
    body: &Body,
    expr_id: Idx<Expr>,
    args: &Vec<crate::hir::Arg>,
    ctx: &mut TypeContext,
    classes: &ClassIndex,
    enums: &EnumIndex,
    interfaces: &InterfaceIndex,
    functions: &FunctionIndex,
    errors: &mut Vec<TypeError>,
    allow_result: bool,
    in_result_fn: bool,
) -> Option<Type> {
    let span = span_from_range(body.expr_span(expr_id));
    if args.len() != 1 {
        errors.push(TypeError::ArgumentCountMismatch {
            expected: 1,
            found: args.len(),
            span,
        });
        return Some(Type::Unknown);
    }
    let value_ty = infer_call_arg_type(
        body,
        &args[0],
        ctx,
        classes,
        enums,
        interfaces,
        functions,
        errors,
        allow_result,
        in_result_fn,
    );
    if is_scalar_numeric_type(&value_ty) {
        return Some(Type::F32);
    }
    if is_vector_like_type(&value_ty) {
        return Some(value_ty);
    }
    push_math_builtin_arg_mismatch(
        "value",
        &value_ty,
        args,
        0,
        "scalar numeric, Vec2, Vec3, Vec4, or Quat",
        errors,
    );
    Some(Type::Unknown)
}

pub(super) fn infer_componentwise_binary_builtin(
    body: &Body,
    expr_id: Idx<Expr>,
    args: &Vec<crate::hir::Arg>,
    ctx: &mut TypeContext,
    classes: &ClassIndex,
    enums: &EnumIndex,
    interfaces: &InterfaceIndex,
    functions: &FunctionIndex,
    errors: &mut Vec<TypeError>,
    allow_result: bool,
    in_result_fn: bool,
) -> Option<Type> {
    let span = span_from_range(body.expr_span(expr_id));
    if args.len() != 2 {
        errors.push(TypeError::ArgumentCountMismatch {
            expected: 2,
            found: args.len(),
            span,
        });
        return Some(Type::Unknown);
    }
    let left_ty = infer_call_arg_type(
        body,
        &args[0],
        ctx,
        classes,
        enums,
        interfaces,
        functions,
        errors,
        allow_result,
        in_result_fn,
    );
    let right_ty = infer_call_arg_type(
        body,
        &args[1],
        ctx,
        classes,
        enums,
        interfaces,
        functions,
        errors,
        allow_result,
        in_result_fn,
    );
    match (left_ty, right_ty) {
        (left, right) if is_scalar_numeric_type(&left) && is_scalar_numeric_type(&right) => {
            Some(Type::F32)
        }
        (left, right) if is_vector_like_type(&left) && is_vector_like_type(&right) => {
            if same_vector_like_kind(&left, &right).is_some() {
                Some(left)
            } else {
                push_math_builtin_arg_mismatch(
                    "left",
                    &left,
                    args,
                    0,
                    "matching Vec2, Vec3, Vec4, or Quat operands",
                    errors,
                );
                push_math_builtin_arg_mismatch(
                    "right",
                    &right,
                    args,
                    1,
                    "matching Vec2, Vec3, Vec4, or Quat operands",
                    errors,
                );
                Some(Type::Unknown)
            }
        }
        (left, right) if is_vector_like_type(&left) && is_scalar_numeric_type(&right) => Some(left),
        (left, right) if is_scalar_numeric_type(&left) && is_vector_like_type(&right) => {
            Some(right)
        }
        (left, right) => {
            push_math_builtin_arg_mismatch(
                "left",
                &left,
                args,
                0,
                "scalar numeric, Vec2, Vec3, Vec4, or Quat",
                errors,
            );
            push_math_builtin_arg_mismatch(
                "right",
                &right,
                args,
                1,
                "scalar numeric, Vec2, Vec3, Vec4, or Quat",
                errors,
            );
            Some(Type::Unknown)
        }
    }
}

pub(super) fn infer_componentwise_ternary_builtin(
    body: &Body,
    expr_id: Idx<Expr>,
    args: &Vec<crate::hir::Arg>,
    ctx: &mut TypeContext,
    classes: &ClassIndex,
    enums: &EnumIndex,
    interfaces: &InterfaceIndex,
    functions: &FunctionIndex,
    errors: &mut Vec<TypeError>,
    allow_result: bool,
    in_result_fn: bool,
) -> Option<Type> {
    let span = span_from_range(body.expr_span(expr_id));
    if args.len() != 3 {
        errors.push(TypeError::ArgumentCountMismatch {
            expected: 3,
            found: args.len(),
            span,
        });
        return Some(Type::Unknown);
    }
    let value_ty = infer_call_arg_type(
        body,
        &args[0],
        ctx,
        classes,
        enums,
        interfaces,
        functions,
        errors,
        allow_result,
        in_result_fn,
    );
    let min_ty = infer_call_arg_type(
        body,
        &args[1],
        ctx,
        classes,
        enums,
        interfaces,
        functions,
        errors,
        allow_result,
        in_result_fn,
    );
    let max_ty = infer_call_arg_type(
        body,
        &args[2],
        ctx,
        classes,
        enums,
        interfaces,
        functions,
        errors,
        allow_result,
        in_result_fn,
    );
    if is_scalar_numeric_type(&value_ty) {
        if is_scalar_numeric_type(&min_ty) && is_scalar_numeric_type(&max_ty) {
            return Some(Type::F32);
        }
        push_math_builtin_arg_mismatch("min", &min_ty, args, 1, "scalar numeric", errors);
        push_math_builtin_arg_mismatch("max", &max_ty, args, 2, "scalar numeric", errors);
        return Some(Type::Unknown);
    }
    if !is_vector_like_type(&value_ty) {
        push_math_builtin_arg_mismatch(
            "value",
            &value_ty,
            args,
            0,
            "scalar numeric, Vec2, Vec3, Vec4, or Quat",
            errors,
        );
        return Some(Type::Unknown);
    }
    if !arg_matches_componentwise_shape(&min_ty, &value_ty) {
        push_math_builtin_arg_mismatch(
            "min",
            &min_ty,
            args,
            1,
            "scalar numeric or matching vector/quaternion",
            errors,
        );
        return Some(Type::Unknown);
    }
    if !arg_matches_componentwise_shape(&max_ty, &value_ty) {
        push_math_builtin_arg_mismatch(
            "max",
            &max_ty,
            args,
            2,
            "scalar numeric or matching vector/quaternion",
            errors,
        );
        return Some(Type::Unknown);
    }
    Some(value_ty)
}

pub(super) fn infer_scalar_cast_builtin(
    body: &Body,
    expr_id: Idx<Expr>,
    args: &Vec<crate::hir::Arg>,
    ctx: &mut TypeContext,
    classes: &ClassIndex,
    enums: &EnumIndex,
    interfaces: &InterfaceIndex,
    functions: &FunctionIndex,
    errors: &mut Vec<TypeError>,
    allow_result: bool,
    in_result_fn: bool,
    target: Type,
) -> Option<Type> {
    let span = span_from_range(body.expr_span(expr_id));
    if args.len() != 1 {
        errors.push(TypeError::ArgumentCountMismatch {
            expected: 1,
            found: args.len(),
            span,
        });
        return Some(Type::Unknown);
    }
    let value_ty = infer_call_arg_type(
        body,
        &args[0],
        ctx,
        classes,
        enums,
        interfaces,
        functions,
        errors,
        allow_result,
        in_result_fn,
    );
    if matches!(value_ty, Type::Unknown) {
        return Some(Type::Unknown);
    }
    if is_scalar_numeric_type(&value_ty) {
        return Some(target);
    }
    push_math_builtin_arg_mismatch("value", &value_ty, args, 0, "scalar numeric", errors);
    Some(Type::Unknown)
}

pub(super) fn push_math_builtin_arg_mismatch(
    name: &str,
    found: &Type,
    args: &[crate::hir::Arg],
    index: usize,
    expected: &str,
    errors: &mut Vec<TypeError>,
) {
    let Some(arg) = args.get(index) else {
        return;
    };
    let span = match arg {
        crate::hir::Arg::Positional { span, .. } | crate::hir::Arg::Named { span, .. } => {
            span_from_range(*span)
        }
    };
    errors.push(TypeError::ArgumentTypeMismatch {
        name: SmolStr::new(name),
        expected: expected.to_string(),
        found: type_label(found),
        span,
    });
}

pub(super) fn is_scalar_numeric_type(ty: &Type) -> bool {
    matches!(
        ty,
        Type::Integer
            | Type::I32
            | Type::U32
            | Type::I64
            | Type::U64
            | Type::Float
            | Type::F32
            | Type::Number
    )
}

pub(super) fn is_vector_like_type(ty: &Type) -> bool {
    matches!(ty, Type::Vec2 | Type::Vec3 | Type::Vec4 | Type::Quat)
}

pub(super) fn is_vector_only_type(ty: &Type) -> bool {
    matches!(ty, Type::Vec2 | Type::Vec3 | Type::Vec4)
}

pub(super) fn is_same_vector_kind(left: &Type, right: &Type) -> bool {
    matches!(
        (left, right),
        (Type::Vec2, Type::Vec2)
            | (Type::Vec3, Type::Vec3)
            | (Type::Vec4, Type::Vec4)
            | (Type::Quat, Type::Quat)
    )
}

pub(super) fn same_vector_like_kind(left: &Type, right: &Type) -> Option<Type> {
    match (left, right) {
        (Type::Vec2, Type::Vec2) => Some(Type::Vec2),
        (Type::Vec3, Type::Vec3) => Some(Type::Vec3),
        (Type::Vec4, Type::Vec4) => Some(Type::Vec4),
        (Type::Quat, Type::Quat) => Some(Type::Quat),
        _ => None,
    }
}

pub(super) fn arg_matches_componentwise_shape(arg: &Type, shape: &Type) -> bool {
    matches!(arg, Type::Unknown)
        || is_scalar_numeric_type(arg)
        || (is_vector_like_type(arg) && is_same_vector_kind(arg, shape))
}

pub(super) fn vector_component_type(object_ty: &Type, member: &SmolStr) -> Option<Type> {
    let member = member.as_str();
    match object_ty {
        Type::Vec2 => match member {
            "x" | "y" => Some(Type::F32),
            _ => None,
        },
        Type::Vec3 => match member {
            "x" | "y" | "z" => Some(Type::F32),
            _ => None,
        },
        Type::Vec4 | Type::Quat => match member {
            "x" | "y" | "z" | "w" => Some(Type::F32),
            _ => None,
        },
        _ => None,
    }
}
